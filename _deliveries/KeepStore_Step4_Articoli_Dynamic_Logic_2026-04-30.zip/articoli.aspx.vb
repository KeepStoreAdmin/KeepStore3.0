Imports MySql.Data.MySqlClient
Imports System.Data
Imports System.Text
Imports System.Web
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Collections.Generic
Imports System.Web.UI.WebControls

Partial Class Articoli
    Inherits AntiCsrfPage

    Dim IvaTipo As Integer
    Dim DispoTipo As Integer
    Dim DispoMinima As Integer
    Dim InOfferta As Integer
    Dim filters As New Dictionary(Of String, String)
    Dim oldUrl As String

    Private Class ActiveFilterItem
        Public Property Key As String
        Public Property Label As String
    End Class

    Function sostituisci_caratteri_speciali(ByRef stringa As String) As String
        stringa = Server.HtmlEncode(stringa)

        'Espressione Regolare per sostituire i caratteri speciali
        Dim pattern As String = "\s+"
        Dim stringaReplace As String = " "
        Dim rgx As New Regex(pattern)
        stringa = rgx.Replace(stringa, stringaReplace)

        stringa = stringa.Replace("&", "")
        stringa = stringa.Replace("!", "")
        stringa = stringa.Trim

        Return stringa
    End Function

    Private Function AreArraysEqual(Of T)(ByVal a As T(), ByVal b() As T) As Boolean
        If a Is Nothing AndAlso b Is Nothing Then Return True
        If a Is Nothing Or b Is Nothing Then Return False
        If a.Length <> b.Length Then Return False

        For i As Integer = 0 To b.GetUpperBound(0)
            If Not Array.IndexOf(a, b(i)) >= 0 Then Return False
        Next

        Return True
    End Function

    Protected Sub Page_PreRenderComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRenderComplete
        Dim newUrl As String = oldUrl
        Dim mrAreEquals As Boolean = True
        Dim tpAreEquals As Boolean = True
        Dim grAreEquals As Boolean = True
        Dim sgAreEquals As Boolean = True

        If filters.ContainsKey("mr") Then
            mrAreEquals = AreArraysEqual(QSSplit("mr"), filters.Item("mr").Split("|"c))
            newUrl = changeUrlGetParam(newUrl, "mr", filters.Item("mr"))
        End If
        If filters.ContainsKey("tp") Then
            tpAreEquals = AreArraysEqual(QSSplit("tp"), filters.Item("tp").Split("|"c))
            newUrl = changeUrlGetParam(newUrl, "tp", filters.Item("tp"))
        End If
        If filters.ContainsKey("gr") Then
            grAreEquals = AreArraysEqual(QSSplit("gr"), filters.Item("gr").Split("|"c))
            newUrl = changeUrlGetParam(newUrl, "gr", filters.Item("gr"))
        End If
        If filters.ContainsKey("sg") Then
            sgAreEquals = AreArraysEqual(QSSplit("sg"), filters.Item("sg").Split("|"c))
            newUrl = changeUrlGetParam(newUrl, "sg", filters.Item("sg"))
        End If

        If Not (mrAreEquals And tpAreEquals And grAreEquals And sgAreEquals) Then
            Response.Redirect(newUrl)
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Step 1: se presente ScriptManager, disabilita partial rendering (rimozione AJAX)
        Dim sm = System.Web.UI.ScriptManager.GetCurrent(Me.Page)
        If sm IsNot Nothing Then sm.EnablePartialRendering = False
        oldUrl = HttpContext.Current.Request.Url.AbsoluteUri

        If Not String.IsNullOrEmpty(Request.QueryString("rimuovi")) Then
            Dim filtersToRemove As String = Request.QueryString("rimuovi")
            Response.Redirect(RemoveActiveFilterFromUrl(GetSafeReturnUrl(), filtersToRemove))
        End If

        

        '==========================================================
        ' STEP 3 (CATALOGO): Normalizzazione parametri st/ct/tp e Session
        ' - Garantisce che i SqlDataSource basati su Session (st/ct) funzionino sempre
        ' - Se arriva solo st o solo ct, completa i parametri mancanti in modo coerente
        '==========================================================
        If Not Me.IsPostBack Then
            EnsureCatalogQueryDefaults()
        End If

        SyncCatalogSessionFromQuery()

        If Me.IsPostBack = False Then
            InitializeCatalogControlsFromRequest()
        End If

        'Redirect nel caso c'è la presenza di #up
        If Request.Url.AbsoluteUri.Contains("%23up") Or (Request.Url.AbsoluteUri.Contains("#23up")) Then
            Response.Redirect(Request.Url.AbsoluteUri.Replace("%23up", "").Replace("#23up", ""))
        End If

        '==========================================================
        ' STEP 27 (SEO): policy indicizzazione (st/ct/tp/gr/sg/mr)
        ' - Decide quali combinazioni possono essere indicizzate
        ' - Imposta Canonical e Robots (meta + X-Robots-Tag)
        '==========================================================
        ApplySeoIndexPolicy()

        Session.Item("Pagina_visitata_Articoli") = Me.Request.Url.ToString 'Aggiorno l'ultima pagina visitata in Articoli
        Me.Session("Carrello_Pagina") = "articoli.aspx"

        DispoTipo = Me.Session("DispoTipo")
        DispoMinima = Me.Session("DispoMinima")
        InOfferta = Me.Session("InOfferta")

        'Assegnazione della variabile in offerta, per visualizzare solo i prodotti in offerta
        Dim rawInPromo As String = Me.Request.QueryString("inpromo")
        If Not String.IsNullOrEmpty(rawInPromo) Then
            Dim tmpInOfferta As Integer
            If Integer.TryParse(rawInPromo, tmpInOfferta) Then
                InOfferta = tmpInOfferta
            End If
        End If
    End Sub

    
    ' ==========================================================
    '  PAGER HELPERS (ListView + DataPager)
    ' ==========================================================
    Private Sub ApplyPagerSettings(ByVal doDataBind As Boolean)
        Dim pageSize As Integer = 12
        If Session("RigheArticoli") IsNot Nothing Then Integer.TryParse(Session("RigheArticoli").ToString(), pageSize)
        If pageSize <= 0 Then pageSize = 12

        If Me.dpProdotti IsNot Nothing Then
            Me.dpProdotti.PageSize = pageSize

            Dim pageIndex As Integer = 0
            If Session("Articoli_PageIndex") IsNot Nothing Then Integer.TryParse(Session("Articoli_PageIndex").ToString(), pageIndex)
            If pageIndex < 0 Then pageIndex = 0

            Dim startRow As Integer = pageIndex * pageSize
            Me.dpProdotti.SetPageProperties(startRow, pageSize, doDataBind)
        End If

        If Me.lblLinee IsNot Nothing Then Me.lblLinee.Text = pageSize.ToString()
        SelectDropDownValueSafe(Me.Drop_Righe, pageSize.ToString())
    End Sub

    Protected Sub lvProdotti_PagePropertiesChanging(ByVal sender As Object, ByVal e As PagePropertiesChangingEventArgs)
        ' Salvo la pagina corrente per mantenere lo stato tra postback/filtri
        Dim pageIndex As Integer = 0
        If e.MaximumRows > 0 Then pageIndex = CInt(Math.Floor(e.StartRowIndex / e.MaximumRows))
        Session("Articoli_PageIndex") = pageIndex

        If Me.dpProdotti IsNot Nothing Then
            Me.dpProdotti.SetPageProperties(e.StartRowIndex, e.MaximumRows, False)
        End If
    End Sub

Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        IvaTipo = Me.Session("IvaTipo")

        If IvaTipo = 1 Then
            Me.lblPrezzi.Text = "*Prezzi Iva Esclusa*"
        ElseIf IvaTipo = 2 Then
            Me.lblPrezzi.Text = "*Prezzi Iva Inclusa*"
        End If

        CaricaArticoli()
        BindActiveFilters()

        ApplyPagerSettings(False)

        'Inserimento della stringa di ricerca nella tabella query_string, per l'indicizzazione
        If Session("q") IsNot Nothing Then
            Dim strCercaQS As String = Session("q")
            Dim paramsQS As New Dictionary(Of String, Object)
            paramsQS.Add("@QString", strCercaQS)
            paramsQS.Add("@Data", DateTime.Now)
            ExecuteInsert("QString, Data", "query_string", "@QString, @Data", paramsQS)
        End If
    End Sub

    'FILTRI TAGLIA COLORE AGGIUNTI DA ANGELO IL 15/12/2017
    'INIZIO
    Public Sub showFilters(ByVal conn As MySqlConnection, ByVal articoliFiltrati As String)
        Dim tc As Integer = Session("TC")
        If tc = 1 Then
            filtritagliaecolore.Visible = True
            Dim TagliaIndex As Integer
            Dim ColoreIndex As Integer
            Dim TagliaValue As String = String.Empty
            Dim ColoreValue As String = String.Empty

            If Me.IsPostBack = False And Request.QueryString("taglia") <> String.Empty Then
                Dim rawTaglia As String = QS("taglia", 40)
                If Not IsValidIndexAndValue(rawTaglia) Then rawTaglia = ""
                Dim tagliaIndexAndValue As String() = If(String.IsNullOrEmpty(rawTaglia), New String() {}, rawTaglia.Split("|"c))
                If tagliaIndexAndValue.Length >= 2 Then
                    TagliaIndex = CInt(tagliaIndexAndValue(0).ToString)
                    TagliaValue = tagliaIndexAndValue(1)
                End If
            Else
                TagliaIndex = Drop_Filtra_Taglia.SelectedIndex
                TagliaValue = Drop_Filtra_Taglia.SelectedValue
            End If

            If Me.IsPostBack = False And Request.QueryString("colore") <> String.Empty Then
                Dim rawColore As String = QS("colore", 40)
                If Not IsValidIndexAndValue(rawColore) Then rawColore = ""
                Dim coloreIndexAndValue As String() = If(String.IsNullOrEmpty(rawColore), New String() {}, rawColore.Split("|"c))
                If coloreIndexAndValue.Length >= 2 Then
                    ColoreIndex = CInt(coloreIndexAndValue(0).ToString)
                    ColoreValue = coloreIndexAndValue(1)
                End If
            Else
                ColoreIndex = Drop_Filtra_Colore.SelectedIndex
                ColoreValue = Drop_Filtra_Colore.SelectedValue
            End If

            PopulateFilterTCDropdownlist(conn, "taglie", "tagliaid", "coloreid", ColoreIndex, TagliaValue, ColoreValue, Drop_Filtra_Taglia, "Tutte", articoliFiltrati)
            PopulateFilterTCDropdownlist(conn, "colori", "coloreid", "tagliaid", TagliaIndex, ColoreValue, TagliaValue, Drop_Filtra_Colore, "Tutti", articoliFiltrati)
        Else
            filtritagliaecolore.Visible = False
        End If
    End Sub

    Public Sub PopulateFilterTCDropdownlist(ByVal conn As MySqlConnection,
                                            ByVal tableName As String,
                                            ByVal idColumnName As String,
                                            ByVal otherIdColumnName As String,
                                            ByVal otherDropdownlistIndex As Integer,
                                            ByVal dropdownlistValue As String,
                                            ByVal otherDropdownlistValue As String,
                                            ByVal list As DropDownList,
                                            ByVal allValueString As String,
                                            ByVal articoliFiltrati As String)

        Dim sqlString As String
        sqlString = "select * from " & tableName & " inner join articoli_tagliecolori where " & tableName & ".id = articoli_tagliecolori." & idColumnName
        Dim otherIdParam As Integer = 0
Dim useOtherParam As Boolean = False
If otherDropdownlistIndex > 0 Then
    If Integer.TryParse(otherDropdownlistValue, otherIdParam) AndAlso otherIdParam > 0 Then
        useOtherParam = True
        sqlString = sqlString & " And articoli_tagliecolori." & otherIdColumnName & " = ?OtherId"
    End If
End If
sqlString = sqlString & " And articoli_tagliecolori.ArticoliId in (SELECT id FROM (" & articoliFiltrati & ") AS articoliFiltrati)"
sqlString = sqlString & " And " & tableName & ".abilitato = 1 Group by " & tableName & ".id order by " & tableName & ".id"

If useOtherParam Then
    Dim cmdDrop As New MySqlCommand(sqlString, conn)
    cmdDrop.Parameters.AddWithValue("?OtherId", otherIdParam)
    PopulateDropdownlist(conn, cmdDrop, list, "descrizione", "id")
Else
    PopulateDropdownlist(conn, sqlString, list, "descrizione", "id")
End If

list.Items.Insert(0, New ListItem(allValueString, "0"))
        SelectDropDownValueSafe(list, dropdownlistValue)
    End Sub

    Public Sub PopulateDropdownlist(ByVal conn As MySqlConnection,
                                    ByVal sqlString As String,
                                    ByVal list As DropDownList,
                                    ByVal textField As String,
                                    ByVal valueField As String)
        Dim dt As New DataTable
        Using cmd = conn.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = sqlString
            Using da As New MySqlDataAdapter(cmd)
                da.Fill(dt)
            End Using
        End Using
        list.DataSource = dt
        list.DataTextField = textField
        list.DataValueField = valueField
        list.DataBind()

	End Sub

' Overload: usa MySqlCommand già parametrizzato (VB2012-safe)
Public Sub PopulateDropdownlist(ByVal conn As MySqlConnection,
                                ByVal cmd As MySqlCommand,
                                ByVal list As DropDownList,
                                ByVal textField As String,
                                ByVal valueField As String)
    Dim dt As New DataTable
    cmd.Connection = conn
    cmd.CommandType = CommandType.Text
    Using da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
    End Using
    list.DataSource = dt
    list.DataTextField = textField
    list.DataValueField = valueField
    list.DataBind()
End Sub

    'FILTRI TAGLIA COLORE - FINE

    Public Sub CaricaArticoli()
        ' ============================
        ' LISTINO: GESTIONE ROBUSTA
        ' ============================
        Dim NListino As Integer = 1  ' listino di default per anonimi

        Dim rawListinoN As String = Convert.ToString(Session("Listino"))
        Dim tmp As Integer
        If Integer.TryParse(rawListinoN, tmp) AndAlso tmp > 0 Then
            NListino = tmp
        Else
            Session("Listino") = NListino
        End If

        Dim SettoriId As Integer = 0
        Dim CategorieId As Integer = 0
        Dim TipologieId As String = String.Empty
        Dim GruppiId As String = String.Empty
        Dim SottogruppiId As String = String.Empty
        Dim MarcheId As String = String.Empty
        Dim OfferteId As Integer = 0
        Dim strCerca As String = ""
        Dim SpedizioneGratis As Integer = 0

        'Carico le variabili da Sessione se non sono presenti nella QueryString
        Dim rawSt As String = Me.Request.QueryString("st")
        If Not String.IsNullOrEmpty(rawSt) Then
            Integer.TryParse(rawSt, SettoriId)
        ElseIf Me.Session("st") IsNot Nothing Then
            Integer.TryParse(Me.Session("st").ToString(), SettoriId)
        End If

        Dim rawCt As String = Me.Request.QueryString("ct")
        If Not String.IsNullOrEmpty(rawCt) Then
            Integer.TryParse(rawCt, CategorieId)
        ElseIf Me.Session("ct") IsNot Nothing Then
            Integer.TryParse(Me.Session("ct").ToString(), CategorieId)
        End If

        Dim rawPid As String = Me.Request.QueryString("pid")
        If Not String.IsNullOrEmpty(rawPid) Then
            Integer.TryParse(rawPid, OfferteId)
        ElseIf Me.Session("pid") IsNot Nothing Then
            Integer.TryParse(Me.Session("pid").ToString(), OfferteId)
        End If

        Dim rawSped As String = Me.Request.QueryString("spedgratis")
        If Not String.IsNullOrEmpty(rawSped) Then
            Integer.TryParse(rawSped, SpedizioneGratis)
        End If

        Me.sdsArticoli.SelectParameters.Clear()
        Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("NListino", TypeCode.Int32, NListino.ToString()))

        ' Filtri multipli (tipologie, gruppi, sottogruppi, marche) da QueryString: accetto solo ID numerici
        TipologieId = SafeIdListFromQuery("tp")
        GruppiId = SafeIdListFromQuery("gr")
        SottogruppiId = SafeIdListFromQuery("sg")
        MarcheId = SafeIdListFromQuery("mr")

        If QS("q", 80) <> "" Then
            strCerca = QS("q", 80).Replace("%23up", "").Replace("#up", "")
        Else
            If Session("q") IsNot Nothing Then
                strCerca = sostituisci_caratteri_speciali(Session("q").Replace("%23up", "").Replace("#up", ""))
            End If
        End If

        If InOfferta = 1 Then
            Session("Promo") = 1
        Else
            Session("Promo") = 0
        End If

        If Not strCerca Is Nothing Then
            strCerca = strCerca.Replace("'", "").Replace("*", "").Replace("&", "").Replace("#", "")
        Else
            strCerca = ""
        End If

        Dim userCerca As String = ""
        Dim searchScoreSql As String = "0 AS SearchScore"
        Dim searchWhereMain As String = ""
        Dim searchWhereFilters As String = ""

        If Not String.IsNullOrEmpty(Convert.ToString(strCerca)) Then
            userCerca = NormalizeQuery(Convert.ToString(strCerca), 120)
        End If

        If userCerca <> "" Then
            Dim exactTerm As String = userCerca.ToLowerInvariant()
            Dim likeTerm As String = "%" & SqlEscapeLike(userCerca).ToLowerInvariant() & "%"
            Dim prefixTerm As String = SqlEscapeLike(userCerca).ToLowerInvariant() & "%"
            Dim searchTokens As List(Of String) = IntelligentSearch.ExpandSearchTokens(userCerca, 10)
            Dim scoreBuilder As New StringBuilder()
            Dim mainWhereBuilder As New StringBuilder()
            Dim filtersWhereBuilder As New StringBuilder()

            Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("qExact", TypeCode.String, exactTerm))
            Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("qLike", TypeCode.String, likeTerm))
            Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("qPrefix", TypeCode.String, prefixTerm))

            scoreBuilder.Append("((CASE ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Codice,'')))=?qExact THEN 10000000 ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Ean,'')))=?qExact THEN 9900000 ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Descrizione1,'')))=?qExact THEN 9800000 ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Codice,''))) LIKE ?qPrefix OR LOWER(CONCAT(' ',COALESCE(Codice,''))) LIKE CONCAT('% ',?qExact,'%') THEN 8800000 ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Ean,''))) LIKE ?qPrefix OR LOWER(CONCAT(' ',COALESCE(Ean,''))) LIKE CONCAT('% ',?qExact,'%') THEN 8700000 ")
            scoreBuilder.Append("WHEN LOWER(TRIM(COALESCE(Descrizione1,''))) LIKE ?qPrefix OR LOWER(CONCAT(' ',COALESCE(Descrizione1,''))) LIKE CONCAT('% ',?qExact,'%') THEN 8600000 ")
            scoreBuilder.Append("WHEN LOWER(CONCAT(' ',COALESCE(MarcheDescrizione,''),' ',COALESCE(Descrizione1,''))) LIKE CONCAT('% ',?qExact,'%') THEN 8200000 ")
            scoreBuilder.Append("WHEN LOWER(COALESCE(Descrizione1,'')) LIKE ?qLike THEN 3600000 ")
            scoreBuilder.Append("WHEN LOWER(COALESCE(DescrizioneLunga,'')) LIKE ?qLike THEN 2600000 ")
            scoreBuilder.Append("WHEN LOWER(COALESCE(MarcheDescrizione,'')) LIKE ?qLike THEN 2400000 ")
            scoreBuilder.Append("WHEN LOWER(COALESCE(Descrizione2,'')) LIKE ?qLike THEN 1800000 ")
            scoreBuilder.Append("ELSE 0 END)")

            mainWhereBuilder.Append(" AND (")
            mainWhereBuilder.Append("LOWER(COALESCE(Codice,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(COALESCE(Ean,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(COALESCE(Descrizione1,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(COALESCE(Descrizione2,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(COALESCE(DescrizioneLunga,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(COALESCE(MarcheDescrizione,'')) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(CONCAT(' ',COALESCE(MarcheDescrizione,''),' ',COALESCE(Descrizione1,''))) LIKE CONCAT('% ',?qExact,'%') ")
            mainWhereBuilder.Append("OR LOWER(CONCAT(COALESCE(MarcheDescrizione,''),' ',COALESCE(Descrizione1,''))) LIKE ?qLike ")
            mainWhereBuilder.Append("OR LOWER(CONCAT(COALESCE(MarcheDescrizione,''),' ',COALESCE(Descrizione2,''))) LIKE ?qLike ")

            filtersWhereBuilder.Append(" AND (")
            filtersWhereBuilder.Append("LOWER(COALESCE(varticolibase.Codice,'')) LIKE ?qLike ")
            filtersWhereBuilder.Append("OR LOWER(COALESCE(varticolibase.Ean,'')) LIKE ?qLike ")
            filtersWhereBuilder.Append("OR LOWER(COALESCE(varticolibase.Descrizione1,'')) LIKE ?qLike ")


            For i As Integer = 0 To searchTokens.Count - 1
                Dim token As String = searchTokens(i).ToLowerInvariant()
                Dim tokenName As String = "qt" & i.ToString()
                Dim tokenLikeName As String = "qtLike" & i.ToString()
                Dim tokenPrefixName As String = "qtPrefix" & i.ToString()

                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter(tokenName, TypeCode.String, token))
                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter(tokenLikeName, TypeCode.String, "%" & SqlEscapeLike(token) & "%"))
                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter(tokenPrefixName, TypeCode.String, SqlEscapeLike(token) & "%"))

                scoreBuilder.Append(" + (CASE ")
                scoreBuilder.Append("WHEN LOWER(Codice)=?").Append(tokenName).Append(" THEN 300 ")
                scoreBuilder.Append("WHEN LOWER(Ean)=?").Append(tokenName).Append(" THEN 280 ")
                scoreBuilder.Append("WHEN LOWER(Codice) LIKE ?").Append(tokenPrefixName).Append(" THEN 220 ")
                scoreBuilder.Append("WHEN LOWER(Ean) LIKE ?").Append(tokenPrefixName).Append(" THEN 200 ")
                scoreBuilder.Append("WHEN LOWER(Descrizione1) LIKE ?").Append(tokenPrefixName).Append(" THEN 180 ")
                scoreBuilder.Append("WHEN LOWER(CONCAT(IFNULL(MarcheDescrizione,''),' ',IFNULL(Descrizione1,''))) LIKE ?").Append(tokenLikeName).Append(" THEN 150 ")
                scoreBuilder.Append("WHEN LOWER(CONCAT(IFNULL(SettoriDescrizione,''),' ',IFNULL(CategorieDescrizione,''),' ',IFNULL(TipologieDescrizione,''),' ',IFNULL(GruppiDescrizione,''),' ',IFNULL(SottogruppiDescrizione,''))) LIKE ?").Append(tokenLikeName).Append(" THEN 130 ")
                scoreBuilder.Append("WHEN LOWER(DescrizioneLunga) LIKE ?").Append(tokenLikeName).Append(" THEN 90 ")
                scoreBuilder.Append("WHEN LOWER(Descrizione2) LIKE ?").Append(tokenLikeName).Append(" THEN 80 ")
                scoreBuilder.Append("ELSE 0 END)")

                mainWhereBuilder.Append("OR LOWER(Codice)=?").Append(tokenName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(Ean)=?").Append(tokenName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(Codice) LIKE ?").Append(tokenPrefixName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(Ean) LIKE ?").Append(tokenPrefixName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(Descrizione1) LIKE ?").Append(tokenLikeName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(Descrizione2) LIKE ?").Append(tokenLikeName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(DescrizioneLunga) LIKE ?").Append(tokenLikeName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(CONCAT(IFNULL(MarcheDescrizione,''),' ',IFNULL(Descrizione1,''))) LIKE ?").Append(tokenLikeName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(CONCAT(IFNULL(MarcheDescrizione,''),' ',IFNULL(Descrizione2,''))) LIKE ?").Append(tokenLikeName).Append(" ")
                mainWhereBuilder.Append("OR LOWER(CONCAT(IFNULL(SettoriDescrizione,''),' ',IFNULL(CategorieDescrizione,''),' ',IFNULL(TipologieDescrizione,''),' ',IFNULL(GruppiDescrizione,''),' ',IFNULL(SottogruppiDescrizione,''))) LIKE ?").Append(tokenLikeName).Append(" ")

                filtersWhereBuilder.Append("OR LOWER(varticolibase.Codice)=?").Append(tokenName).Append(" ")
                filtersWhereBuilder.Append("OR LOWER(varticolibase.Ean)=?").Append(tokenName).Append(" ")
                filtersWhereBuilder.Append("OR LOWER(varticolibase.Codice) LIKE ?").Append(tokenPrefixName).Append(" ")
                filtersWhereBuilder.Append("OR LOWER(varticolibase.Ean) LIKE ?").Append(tokenPrefixName).Append(" ")
                filtersWhereBuilder.Append("OR LOWER(varticolibase.Descrizione1) LIKE ?").Append(tokenLikeName).Append(" ")
            Next

            mainWhereBuilder.Append(")")
            filtersWhereBuilder.Append(")")

            scoreBuilder.Append(" + (CASE WHEN COALESCE(Disponibilita,0)>0 THEN 600 ELSE 0 END)")
            scoreBuilder.Append(" + (CASE WHEN COALESCE(Export,1)<>0 THEN 500 ELSE 0 END)")
            scoreBuilder.Append(" + (CASE WHEN COALESCE(InOfferta,0)<>0 THEN 450 ELSE 0 END)")
            scoreBuilder.Append(" + (CASE WHEN COALESCE(Vetrina,0)<>0 THEN 250 ELSE 0 END)")
            scoreBuilder.Append(" + LEAST(COALESCE(visite,0),999)")
            scoreBuilder.Append(")")

            searchScoreSql = scoreBuilder.ToString() & " AS SearchScore"
            searchWhereMain = mainWhereBuilder.ToString()
            searchWhereFilters = filtersWhereBuilder.ToString()
        End If

        ' valori IVA da Session in forma numerica sicura
        Dim abilRC As Integer = 0
        Dim ivaUtente As Integer = 0
        If Session("AbilitatoIvaReverseCharge") IsNot Nothing Then
            Integer.TryParse(Session("AbilitatoIvaReverseCharge").ToString(), abilRC)
        End If
        If Session("Iva_Utente") IsNot Nothing Then
            Integer.TryParse(Session("Iva_Utente").ToString(), ivaUtente)
        End If

        Dim strSelect As String =
            "SELECT vsuperarticoli.id, Codice, Ean, Descrizione1, Descrizione2, DescrizioneLunga, Prezzo," &
            " IF((" & abilRC & "=1) AND (ValoreIvaRC>-1)," &
            "     (Prezzo*((ValoreIvaRC/100)+1))," &
            "     IF(" & ivaUtente & ">0,(Prezzo*((" & ivaUtente & "/100)+1)),PrezzoIvato)" &
            " ) AS PrezzoIvato," &
            " Img1, MarcheDescrizione, Disponibilita, Giacenza, InOrdine, Impegnata, InOfferta," &
            " SettoriDescrizione, CategorieDescrizione, TipologieDescrizione, GruppiDescrizione, SottogruppiDescrizione," &
            " Marche_img, PrezzoPromo," &
            " IF((" & abilRC & "=1) AND (ValoreIvaRC>-1)," &
            "     (PrezzoPromo*((ValoreIvaRC/100)+1))," &
            "     IF(" & ivaUtente & ">0,(PrezzoPromo*((" & ivaUtente & "/100)+1)),PrezzoPromoIvato)" &
            " ) AS PrezzoPromoIvato," &
            " MarcheId, CategorieId, TipologieId," &
            " IF(PrezzoPromo IS NULL,Prezzo,PrezzoPromo) AS Ord_PrezzoPromo," &
            " IF(PrezzoPromoIvato IS NULL,PrezzoIvato," &
            "     IF((" & abilRC & "=1) AND (ValoreIvaRC>-1)," &
            "         (PrezzoPromo*((ValoreIvaRC/100)+1))," &
            "         IF(" & ivaUtente & ">0,(PrezzoPromo*((" & ivaUtente & "/100)+1)),PrezzoPromoIvato)" &
            "     )" &
            " ) AS Ord_PrezzoPromoIvato," &
            " TCid, IF(Ricondizionato = 1, 'visible', 'hidden') as refurbished," &
            " taglie.descrizione as taglia," &
            " CONVERT(CONCAT('<table style=""width:100%;"" border=""1""><tr style=""background-color:#00FF99;""><td>Data di arrivo</td><td>Quantit&agrave;</td></tr><tr style=""background-color:#00FFFF;""><td>'," &
            "       GROUP_CONCAT(arrivi SEPARATOR '</td></tr><tr style=""background-color:#00FFFF;""><td>'),'</td></tr></table>'),CHAR) as arrivi," &
            " colori.descrizione as colore," &
            " IF(PrezzoPromoIvato IS NULL, PrezzoIvato, PrezzoPromoIvato) AS PrezzoOldIvato," &
            " " & searchScoreSql &
            " FROM vsuperarticoli " &
            " LEFT OUTER JOIN articoli_tagliecolori On vsuperarticoli.TCid=articoli_tagliecolori.id" &
            " LEFT OUTER JOIN taglie ON articoli_tagliecolori.tagliaid = taglie.id" &
            " LEFT OUTER JOIN colori ON articoli_tagliecolori.coloreid = colori.id" &
            " LEFT OUTER JOIN (SELECT articoliid, CONCAT(DATE_FORMAT(dataArrivo, '%d/%m/%Y'),'</td><td>', (TRIM(TRAILING '.' FROM(CAST(TRIM(TRAILING '0' FROM SUM(arrivi)) AS CHAR))))) AS arrivi" &
            "                 FROM articoli_arrivi WHERE dataArrivo>NOW() and arrivi > 0 GROUP BY dataArrivo) arrivi ON arrivi.articoliid = vsuperarticoli.id"

        Dim strWhere As String = ""
        Dim strWhere2 As String = "WHERE 1=1 "

        
        ' placeholders IN-lists (VB2012-safe)
        Dim inMr As String = ""
        Dim inTp As String = ""
        Dim inGr As String = ""
        Dim inSg As String = ""
If SettoriId > 0 And OfferteId = 0 Then
            ' logica per settore (lasciata commentata come nel codice originale)
        End If

        If CategorieId > 0 Then
            If (Session("ct") <> 30000) Then
                strWhere &= " AND (CategorieId=?CategorieId) "
                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("CategorieId", TypeCode.Int32, CategorieId.ToString()))
                strWhere2 = strWhere2 & " AND (varticolibase.CategorieId=?CategorieId) "
            End If
            TitoloCategoria()
        ElseIf OfferteId > 0 Then
            strWhere &= " AND (OfferteId=?OfferteId) "
            Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("OfferteId", TypeCode.Int32, OfferteId.ToString()))
            strWhere2 = strWhere2 & " AND (varticolibase.OfferteId=?OfferteId) "
            Me.tNavig.Visible = False
        ElseIf strCerca = "" OrElse strCerca Is Nothing Then
            Response.Redirect("default.aspx")
        End If

        If Not String.IsNullOrEmpty(MarcheId) Then
            inMr = BuildInParamsForSds(MarcheId, "mr", Me.sdsArticoli.SelectParameters)
            If inMr <> "" Then
                strWhere &= " AND MarcheId IN (" & inMr & ") "
                strWhere2 &= " AND varticolibase.MarcheId IN (" & inMr & ") "
            End If
        End If

        If Not String.IsNullOrEmpty(TipologieId) Then
            inTp = BuildInParamsForSds(TipologieId, "tp", Me.sdsArticoli.SelectParameters)
            If inTp <> "" Then
                strWhere &= " AND TipologieId IN (" & inTp & ") "
                strWhere2 &= " AND varticolibase.TipologieId IN (" & inTp & ") "
            End If
        End If

       If Not String.IsNullOrEmpty(GruppiId) Then
            inGr = BuildInParamsForSds(GruppiId, "gr", Me.sdsArticoli.SelectParameters)
            If inGr <> "" Then
                strWhere &= " AND GruppiId IN (" & inGr & ") "
                strWhere2 &= " AND varticolibase.GruppiId IN (" & inGr & ") "
            End If
        End If

       If Not String.IsNullOrEmpty(SottogruppiId) Then
            inSg = BuildInParamsForSds(SottogruppiId, "sg", Me.sdsArticoli.SelectParameters)
            If inSg <> "" Then
                strWhere &= " AND SottogruppiId IN (" & inSg & ") "
                strWhere2 &= " AND varticolibase.SottogruppiId IN (" & inSg & ") "
            End If
        End If

         If SpedizioneGratis = 1 Then
            strWhere = strWhere &
                " AND (SpedizioneGratis_Listini LIKE CONCAT('%', ?NListino, ';%'))" &
                " AND (SpedizioneGratis_Data_Inizio <= CURDATE())" &
                " AND (SpedizioneGratis_Data_Fine >= CURDATE())"
            strWhere2 = strWhere2 &
                " AND (SpedizioneGratis_Listini LIKE CONCAT('%', ?NListino, ';%'))" &
                " AND (SpedizioneGratis_Data_Inizio <= CURDATE())" &
                " AND (SpedizioneGratis_Data_Fine >= CURDATE())"
        Else
            Me.Session("SpedGratis") = 0
        End If

        'Filtro PROMO (InOfferta=1) - logica compatta e stabile:
' - attivo se arriva ?inpromo=1 oppure se Session("Promo")=1 (one-shot)
' - applica il filtro sia a strWhere che a strWhere2
Dim promoActive As Boolean = (InOfferta = 1)

If Not promoActive Then
    Dim promoObj As Object = Session.Item("Promo")
    Dim promoInt As Integer = 0
    If promoObj IsNot Nothing AndAlso Integer.TryParse(promoObj.ToString(), promoInt) AndAlso promoInt = 1 Then
        promoActive = True
        'one-shot: dopo il primo load lo resettiamo
        Session.Item("Promo") = 0
    End If
End If

If promoActive Then
    'allineiamo anche la variabile per il resto della pagina (datasource promo)
    InOfferta = 1
    strWhere &= " AND (InOfferta = 1) "
    strWhere2 &= " AND (varticolibase.InOfferta = 1) "
End If

        If CheckBox_Disponibile.Checked = True Then
            Session.Item("Disp") = 0
            strWhere = strWhere & " AND (Giacenza>0)"
            strWhere2 = strWhere2 & " AND (Giacenza>0)"
        End If

        If Me.Page.IsPostBack = False Then
            Session.Item("Controllo_Variabile_PrezzoMinMax") = 0
            Session("Valore_Prezzo_MIN") = ""
            Session("Valore_Prezzo_MAX") = ""
        End If

'Gestione filtri prezzo (100% parametrici - VB2012 safe)
If Page.IsPostBack = False Then
    Session("Valore_Prezzo_MIN") = ""
    Session("Valore_Prezzo_MAX") = ""
    Session("Controllo_Variabile_PrezzoMinMax") = 0
End If

' Se arrivano valori dai controlli/Query (Prezzo_MIN/Prezzo_MAX) li congeliamo in Valore_* una sola volta
If (Session.Item("Controllo_Variabile_PrezzoMinMax") = 0) AndAlso
   ((Session.Item("Prezzo_MIN") <> "") OrElse (Session.Item("Prezzo_MAX") <> "")) Then

    If (Session.Item("Prezzo_MIN") <> "") Then
        Session("Valore_Prezzo_MIN") = Session.Item("Prezzo_MIN")
        Session.Item("Prezzo_MIN") = ""
    End If

    If (Session.Item("Prezzo_MAX") <> "") Then
        Session("Valore_Prezzo_MAX") = Session.Item("Prezzo_MAX")
        Session.Item("Prezzo_MAX") = ""
    End If

    Session.Item("Controllo_Variabile_PrezzoMinMax") = 1
End If

' Applica filtro prezzo con parametri (Pmin/Pmax) se valorizzato
Dim hasPmin As Boolean = False
Dim hasPmax As Boolean = False
Dim pminVal As Decimal = 0D
Dim pmaxVal As Decimal = 0D

If Session.Item("Controllo_Variabile_PrezzoMinMax") = 1 Then
    Dim sMin As String = Convert.ToString(Session("Valore_Prezzo_MIN"))
    Dim sMax As String = Convert.ToString(Session("Valore_Prezzo_MAX"))

    If sMin <> "" Then
        Decimal.TryParse(sMin.Replace(",", "."), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, pminVal)
        If pminVal > 0D Then hasPmin = True
    End If

    If sMax <> "" Then
        Decimal.TryParse(sMax.Replace(",", "."), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, pmaxVal)
        If pmaxVal > 0D Then hasPmax = True
    End If

    Dim colPrice As String
    Dim colPromo As String
    If IvaTipo = 2 Then
        colPrice = "PrezzoIvato"
        colPromo = "PrezzoPromoIvato"
    Else
        colPrice = "Prezzo"
        colPromo = "PrezzoPromo"
    End If

    If hasPmin AndAlso hasPmax Then
        strWhere &= " AND ((" & colPromo & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NOT NULL AND " & colPromo & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " BETWEEN ?Pmin AND ?Pmax))"
        strWhere2 &= " AND ((" & colPromo & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NOT NULL AND " & colPromo & " BETWEEN ?Pmin AND ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " BETWEEN ?Pmin AND ?Pmax))"
    ElseIf hasPmin Then
        strWhere &= " AND ((" & colPromo & " >= ?Pmin) OR (" & colPromo & " IS NULL AND " & colPrice & " >= ?Pmin))"
        strWhere2 &= " AND ((" & colPromo & " >= ?Pmin) OR (" & colPromo & " IS NULL AND " & colPrice & " >= ?Pmin))"
    ElseIf hasPmax Then
        strWhere &= " AND ((" & colPromo & " <= ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " <= ?Pmax))"
        strWhere2 &= " AND ((" & colPromo & " <= ?Pmax) OR (" & colPromo & " IS NULL AND " & colPrice & " <= ?Pmax))"
    End If
End If

' Parametri prezzo per SqlDataSource (aggiunti solo se necessari)
If hasPmin Then sdsArticoli.SelectParameters.Add(New Parameter("Pmin", TypeCode.Decimal, pminVal.ToString(System.Globalization.CultureInfo.InvariantCulture)))
If hasPmax Then sdsArticoli.SelectParameters.Add(New Parameter("Pmax", TypeCode.Decimal, pmaxVal.ToString(System.Globalization.CultureInfo.InvariantCulture)))

        Dim TC As Integer = Session("TC")
        If TC = 1 Then
            ' Filtro Taglia/Colore: applicato sia alla query principale (join già presente)
            ' sia a strWhere2 (usato per i conteggi filtri laterali) tramite EXISTS su TCid.
            If Drop_Filtra_Taglia.SelectedIndex > 0 Then
                strWhere &= " AND articoli_tagliecolori.TagliaId=?TagliaId"
                strWhere2 &= " AND EXISTS (SELECT 1 FROM articoli_tagliecolori atc WHERE atc.id = vsuperarticoli.TCid AND atc.TagliaId=?TagliaId)"
                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("TagliaId", TypeCode.Int32, Drop_Filtra_Taglia.SelectedValue))
            End If

            If Drop_Filtra_Colore.SelectedIndex > 0 Then
                strWhere &= " AND articoli_tagliecolori.ColoreId=?ColoreId"
                strWhere2 &= " AND EXISTS (SELECT 1 FROM articoli_tagliecolori atc WHERE atc.id = vsuperarticoli.TCid AND atc.ColoreId=?ColoreId)"
                Me.sdsArticoli.SelectParameters.Add(New System.Web.UI.WebControls.Parameter("ColoreId", TypeCode.Int32, Drop_Filtra_Colore.SelectedValue))
            End If
        End If
        ' --- Ricerca potenziata marketplace ---
        If userCerca <> "" Then
            strWhere &= searchWhereMain
            strWhere2 &= searchWhereFilters
            Me.lblRicerca.Visible = True
            Me.lblRisultati.Text = H(userCerca)
            Me.Title = Me.Title & " > " & lblRicerca.Text & userCerca
        End If

strWhere = strWhere & " GROUP BY id"

        ' Ordinamento (whitelist)
        Dim sortValue As String = Convert.ToString(Drop_Ordinamento.SelectedValue).ToLowerInvariant()
        If sortValue.StartsWith("p_popolar") Then sortValue = "p_popolarita"
        Select Case sortValue
            Case "p_offerta"
                strWhere &= " ORDER BY InOfferta DESC, PrezzoPromo ASC, PrezzoPromoIvato ASC, PrezzoIvato ASC, Prezzo ASC, (Giacenza-Impegnata) DESC"
            Case "p_basso"
                strWhere &= " ORDER BY PrezzoIvato ASC, Prezzo ASC, Ord_PrezzoPromo ASC, Ord_PrezzoPromoIvato ASC, (Giacenza-Impegnata) DESC"
            Case "p_alto"
                strWhere &= " ORDER BY PrezzoIvato DESC, Prezzo DESC, Ord_PrezzoPromo ASC, Ord_PrezzoPromoIvato ASC, (Giacenza-Impegnata) DESC"
            Case "p_popolarita"
                strWhere &= " ORDER BY visite DESC, PrezzoPromo ASC, PrezzoPromoIvato ASC, PrezzoIvato ASC, Prezzo ASC, (Giacenza-Impegnata) DESC"
            Case "p_recenti"
                strWhere &= " ORDER BY id DESC, PrezzoPromo ASC, PrezzoPromoIvato ASC, PrezzoIvato ASC, Prezzo ASC, (Giacenza-Impegnata) DESC"
            Case "p_codice"
                strWhere &= " ORDER BY Codice ASC, (Giacenza-Impegnata) DESC"
            Case "p_descrizione"
                strWhere &= " ORDER BY Descrizione1 ASC, (Giacenza-Impegnata) DESC"
            Case "p_disponibilita"
                strWhere &= " ORDER BY ((Giacenza-Impegnata)>0) DESC, Disponibilita DESC, InOfferta DESC, id DESC"
            Case Else
                ' Default: rilevanza (stabile)
                If userCerca <> "" Then
                    strWhere &= " ORDER BY SearchScore DESC, ((Giacenza-Impegnata)>0) DESC, InOfferta DESC, COALESCE(Vetrina,0) DESC, visite DESC, id DESC"
                Else
                    strWhere &= " ORDER BY (Giacenza-Impegnata) DESC, id DESC"
                End If
        End Select

        If TC = 1 Then
            strWhere = strWhere & " ,articoli_tagliecolori.TagliaId, articoli_tagliecolori.ColoreId"
        End If

        Me.sdsArticoli.SelectCommand = strSelect & " WHERE Nlistino=?NListino " & strWhere

        strWhere2 = " LEFT JOIN vsuperarticoli ON vsuperarticoli.Id = varticolibase.id " & strWhere2 & " AND Nlistino=?NListino"

        Me.sdsMarche.SelectCommand =
            "select Giacenza, `varticolibase`.`MarcheId` AS `MarcheId`,`Marche`.`Descrizione` AS `Descrizione`," &
            "`Marche`.`Ordinamento` AS `Ordinamento`,count(DISTINCT `varticolibase`.`id`) AS `Numero`" &
            " from `varticolibase` join `Marche` on(`varticolibase`.`MarcheId` = `Marche`.`id`) " &
            Regex.Replace(strWhere2, " AND varticolibase.MarcheId in \(([^\)])+\) ", String.Empty) &
            " group by `Marche`.`Descrizione` order by `Marche`.`Ordinamento`, `Marche`.`Descrizione`"

        Me.sdsTipologie.SelectCommand =
            "select Giacenza,`varticolibase`.`TipologieId` AS `TipologieId`,`tipologie`.`Descrizione` AS `Descrizione`," &
            "`tipologie`.`Ordinamento` AS `Ordinamento`,count(DISTINCT `varticolibase`.`id`) AS `Numero`" &
            " from `varticolibase` join `tipologie` on(`varticolibase`.`TipologieId` = `tipologie`.`id`) " &
            Regex.Replace(strWhere2, " AND varticolibase.TipologieId in \(([^\)])+\) ", String.Empty) &
            " group by `tipologie`.`Descrizione` order by `tipologie`.`Ordinamento`, `tipologie`.`Descrizione`"

        Me.sdsGruppo.SelectCommand =
            "select Giacenza,GROUP_CONCAT(DISTINCT `varticolibase`.`GruppiId` SEPARATOR '|') AS `GruppiId`," &
            "`Gruppi`.`Descrizione` AS `Descrizione`,`Gruppi`.`Ordinamento` AS `Ordinamento`," &
            "count(DISTINCT `varticolibase`.`id`) AS `Numero`" &
            " from `varticolibase` join `Gruppi` on(`varticolibase`.`GruppiId` = `Gruppi`.`id`) " &
            Regex.Replace(strWhere2, " AND varticolibase.GruppiId in \(([^\)])+\) ", String.Empty) &
            " group by `Gruppi`.`Descrizione` order by `Gruppi`.`Ordinamento`, `Gruppi`.`Descrizione`"

        Me.sdsSottogruppo.SelectCommand =
            "select Giacenza,`varticolibase`.`SottoGruppiId` AS `SottoGruppiId`," &
            "`SottoGruppi`.`Descrizione` AS `Descrizione`,`SottoGruppi`.`Ordinamento` AS `Ordinamento`," &
            "count(DISTINCT `varticolibase`.`id`) AS `Numero`" &
            " from `varticolibase` join `SottoGruppi` on(`varticolibase`.`SottoGruppiId` = `SottoGruppi`.`id`) " &
            Regex.Replace(strWhere2, " AND varticolibase.SottogruppiId in \(([^\)])+\) ", String.Empty) &
            " group by `SottoGruppi`.`Descrizione` order by `SottoGruppi`.`Ordinamento`, `SottoGruppi`.`Descrizione`"


        ' Ensure all filter datasources reuse the exact same parameters (100% param-only)
        CopyParams(Me.sdsArticoli.SelectParameters, Me.sdsMarche.SelectParameters)
        CopyParams(Me.sdsArticoli.SelectParameters, Me.sdsTipologie.SelectParameters)
        CopyParams(Me.sdsArticoli.SelectParameters, Me.sdsGruppo.SelectParameters)
        CopyParams(Me.sdsArticoli.SelectParameters, Me.sdsSottogruppo.SelectParameters)
        If (InOfferta = 1) Then
            ' Extra promo filters: ONLY parameter placeholders (mr/tp/gr/sg) generated by BuildInParamsForSds.
            ' No raw string values are concatenated into SQL.
            Dim promoExtraFilters As New List(Of String)
            If Not String.IsNullOrEmpty(inMr) Then promoExtraFilters.Add("(MarcheId IN (" & inMr & "))")
            If Not String.IsNullOrEmpty(inTp) Then promoExtraFilters.Add("(TipologieId IN (" & inTp & "))")
            If Not String.IsNullOrEmpty(inGr) Then promoExtraFilters.Add("(GruppiId IN (" & inGr & "))")
            If Not String.IsNullOrEmpty(inSg) Then promoExtraFilters.Add("(SottogruppiId IN (" & inSg & "))")
            Dim promoExtraWhere As String = If(promoExtraFilters.Count > 0, " AND " & String.Join(" AND ", promoExtraFilters.ToArray()), "")

            Me.sdsTipologie.SelectCommand =
                "SELECT *, COUNT(TipologieId) AS Numero FROM (" &
                " SELECT MarcheId, MarcheDescrizione, SettoriId, SettoriDescrizione, CategorieId, CategorieDescrizione," &
                " TipologieId, TipologieDescrizione AS Descrizione, GruppiId, GruppiDescrizione, SottogruppiId, SottogruppiDescrizione" &
                " FROM vsuperarticoli" &
                " WHERE (inofferta=1)" &
                " AND ((?NListino>=OfferteDaListino) AND (?NListino<=OfferteAListino))" &
                " AND (NListino=?NListino)" &
                " AND ((CURDATE()>=offerteDatainizio) AND (CURDATE()<=offerteDataFine))" &
                " AND (TipologieDescrizione IS NOT NULL)" &
                promoExtraWhere &
                " GROUP BY id) AS t1 GROUP BY Tipologieid"

            Me.sdsGruppo.SelectCommand =
                "SELECT *, COUNT(GruppiId) AS Numero FROM (" &
                " SELECT MarcheId, MarcheDescrizione, SettoriId, SettoriDescrizione, CategorieId, CategorieDescrizione," &
                " TipologieId, TipologieDescrizione, GruppiId, GruppiDescrizione AS Descrizione, SottogruppiId, SottogruppiDescrizione" &
                " FROM vsuperarticoli" &
                " WHERE (inofferta=1)" &
                " AND ((?NListino>=OfferteDaListino) AND (?NListino<=OfferteAListino))" &
                " AND (NListino=?NListino)" &
                " AND ((CURDATE()>=offerteDatainizio) AND (CURDATE()<=offerteDataFine))" &
                " AND (GruppiDescrizione IS NOT NULL)" &
                promoExtraWhere &
                " GROUP BY id) AS t1 GROUP BY GruppiId"

            Me.sdsSottogruppo.SelectCommand =
                "SELECT *, COUNT(SottogruppiId) AS Numero FROM (" &
                " SELECT MarcheId, MarcheDescrizione, SettoriId, SettoriDescrizione, CategorieId, CategorieDescrizione," &
                " TipologieId, TipologieDescrizione, GruppiId, GruppiDescrizione, SottogruppiId, SottogruppiDescrizione AS Descrizione" &
                " FROM vsuperarticoli" &
                " WHERE (inofferta=1)" &
                " AND ((?NListino>=OfferteDaListino) AND (?NListino<=OfferteAListino))" &
                " AND (NListino=?NListino)" &
                " AND ((CURDATE()>=offerteDatainizio) AND (CURDATE()<=offerteDataFine))" &
                " AND (SottogruppiDescrizione IS NOT NULL)" &
                promoExtraWhere &
                " GROUP BY id) AS t1 GROUP BY Gruppiid"

            Me.sdsMarche.SelectCommand =
                "SELECT *, COUNT(MarcheId) AS Numero FROM (" &
                " SELECT MarcheId, MarcheDescrizione AS Descrizione, SettoriId, SettoriDescrizione, CategorieId, CategorieDescrizione," &
                " TipologieId, TipologieDescrizione, GruppiId, GruppiDescrizione, SottogruppiId, SottogruppiDescrizione" &
                " FROM vsuperarticoli" &
                " WHERE (inofferta=1)" &
                " AND ((?NListino>=OfferteDaListino) AND (?NListino<=OfferteAListino))" &
                " AND (NListino=?NListino)" &
                " AND ((CURDATE()>=offerteDatainizio) AND (CURDATE()<=offerteDataFine))" &
                " AND (MarcheDescrizione IS NOT NULL)" &
                promoExtraWhere &
                " GROUP BY id) AS t1 GROUP BY marcheid"
        End If

        Dim conn As New MySqlConnection
        conn.ConnectionString = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
        conn.Open()
        showFilters(conn, sdsArticoli.SelectCommand)
        conn.Close()

        Dim sdsArticoliToShow = Me.sdsArticoli.SelectCommand.Replace("'", """").ToUpper
    End Sub

    Public Sub SetSelectedIndex(ByVal dl As DataList, ByVal val As Integer)
        Dim Index As Integer = -1
        Dim hl As HyperLink

        dl.SelectedIndex = 0

        For i As Integer = 0 To dl.Items.Count - 1
            hl = dl.Items(i).FindControl("HyperLink1")
            If hl.TabIndex = val Then
                Index = i
                Me.Title = Me.Title & " > " & hl.Text
            End If
        Next
    End Sub

    Protected Sub sdsArticoli_Selected(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.SqlDataSourceStatusEventArgs) Handles sdsArticoli.Selected
        Me.lblTrovati.Text = e.AffectedRows.ToString
    End Sub
    Function controlla_promo_articolo(ByVal cod_articolo As Integer, ByVal listino As Integer) As Integer
        Dim params As New Dictionary(Of String, Object)
        params.Add("@Listino", listino)
        params.Add("@CodArticolo", cod_articolo)
        Dim dr = ExecuteQueryGetDataReader("id", "vsuperarticoli",
                                           "where (ID=@CodArticolo AND NListino=@Listino) AND (OfferteDataInizio <= CURDATE() AND OfferteDataFine >= CURDATE()) AND InOfferta=1 ORDER BY PrezzoPromo DESC",
                                           params)
        If (dr.Count > 0) Then
            Return 1
        Else
            Return 0
        End If
    End Function
    ' *** LISTVIEW PreRender (UI adjustments) ***
    Protected Sub lvProdotti_PreRender(ByVal sender As Object, ByVal e As System.EventArgs)
        ' Nascondo il bottone Wishlist se l'utente non è loggato
        Dim idUtente As Integer = 0
        If Session.Item("UtentiId") IsNot Nothing Then Integer.TryParse(Session.Item("UtentiId").ToString(), idUtente)
        For Each it As ListViewDataItem In Me.lvProdotti.Items
            Dim lbWishlist As LinkButton = TryCast(it.FindControl("LB_wishlist"), LinkButton)
            If lbWishlist IsNot Nothing AndAlso idUtente <= 0 Then lbWishlist.Visible = False
        Next

        ' Footer multi-selezione e pager: li mostro solo se ho risultati
        Dim hasItems As Boolean = (Me.lvProdotti.Items.Count > 0)
        If Me.ksMultiFooter IsNot Nothing Then Me.ksMultiFooter.Visible = hasItems
        If Me.ksPagerWrap IsNot Nothing Then Me.ksPagerWrap.Visible = hasItems
    End Sub

    ' CLICK SU ICONA "CARRELLO" PER SINGOLO ARTICOLO
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim img As ImageButton = TryCast(sender, ImageButton)
        If img Is Nothing Then Exit Sub

        Dim item As ListViewDataItem = TryCast(img.NamingContainer, ListViewDataItem)
        If item Is Nothing Then Exit Sub

        AddToCartFromItem(item)
    End Sub
    Protected Sub LB_AddToCart_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim lb As LinkButton = TryCast(sender, LinkButton)
        If lb Is Nothing Then Exit Sub

        Dim item As ListViewDataItem = TryCast(lb.NamingContainer, ListViewDataItem)
        If item Is Nothing Then Exit Sub

        AddToCartFromItem(item)
    End Sub

    Private Sub AddToCartFromItem(ByVal item As ListViewDataItem)
        If item Is Nothing Then Exit Sub

        ' Listino corrente (default 1)
        Dim listino As Integer = 1
        Dim rawListino As String = Convert.ToString(Session("Listino"))
        Dim tmpListino As Integer
        If Integer.TryParse(rawListino, tmpListino) AndAlso tmpListino > 0 Then
            listino = tmpListino
        End If

        ' 1) ID ARTICOLO (usando gli helper)
        Dim idVal As Integer = GetArticoloIdFromContainer(item)
        If idVal <= 0 Then
            ' Non riesco a capire che articolo sia, torno semplicemente alla lista
            Response.Redirect("articoli.aspx")
            Return
        End If

        ' 2) QUANTITÀ
        Dim qta As Integer = GetQuantitaFromContainer(item)

        ' 3) TCID (Taglia/Colore) se presente, altrimenti -1
        Dim tcIdVal As Integer = GetTCIdFromContainer(item)

        ' 4) PRODOTTO GRATIS (spedito gratis) calcolato da DB
        Session("ProdottoGratis") = spedito_gratis(idVal, listino)

        ' 5) CONTROLLO SETTORE
        If controlla_abilitazione_settore(idVal) = 1 Then
            ' Preparo le variabili che legge aggiungi.aspx.vb
            Session("Carrello_ArticoloId") = idVal.ToString()
            Session("Carrello_TCId") = tcIdVal.ToString()
            Session("Carrello_Quantita") = qta.ToString()
            Session("Carrello_SelezioneMultipla") = Nothing

            Response.Redirect("aggiungi.aspx")
        Else
            Response.Redirect("settore_disabilitato.aspx")
        End If
    End Sub

    Public Sub TitoloCategoria()
        Dim lblCategoria As Label
        lblCategoria = Me.FormView1.FindControl("lblCategoria")
        If (Not lblCategoria Is Nothing) AndAlso (Session.Item("ct") <> 30000) Then
            Me.Title = Me.Title & " > " & lblCategoria.Text
        Else
            Me.Title = "Tutte le Categorie"
        End If
    End Sub

    Protected Sub DataList1_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList1.PreRender
        Me.DataList1.Visible = (Me.DataList1.Items.Count > 0)
    End Sub

    Protected Sub DataList2_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList2.PreRender
        Me.DataList2.Visible = (Me.DataList2.Items.Count > 0)
    End Sub

    Protected Sub DataList3_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList3.PreRender
        Me.DataList3.Visible = (Me.DataList3.Items.Count > 0)
    End Sub

    Protected Sub DataList4_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList4.PreRender
        Me.DataList4.Visible = (Me.DataList4.Items.Count > 0)
    End Sub

    Protected Sub rPromo_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs)
        ' Rimane qui per compatibilità, ma con il nuovo markup non viene più usato.
        ' Se in futuro ripristini il repeater delle promo, questa logica andrà riallineata al layout.
    End Sub

    Protected Sub Selezione_Multipla_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim listaArticoli As New ArrayList()

        ' Listino corrente (default 1)
        Dim listino As Integer = 1
        Dim rawListino As String = Convert.ToString(Session("Listino"))
        Dim tmpList As Integer
        If Integer.TryParse(rawListino, tmpList) AndAlso tmpList > 0 Then
            listino = tmpList
        End If

        For Each it As ListViewDataItem In Me.lvProdotti.Items
            Dim temp_check As CheckBox = TryCast(it.FindControl("CheckBox_SelezioneMultipla"), CheckBox)
            If temp_check IsNot Nothing AndAlso temp_check.Checked Then

                Dim idVal As Integer = GetArticoloIdFromContainer(it)
                If idVal <= 0 Then Continue For

                ' Controllo settore per ogni articolo selezionato
                If controlla_abilitazione_settore(idVal) <> 1 Then
                    Response.Redirect("settore_disabilitato.aspx")
                    Return
                End If

                Dim tcIdVal As Integer = GetTCIdFromContainer(it)
                Dim qta As Integer = GetQuantitaFromContainer(it)
                Dim prodottoGratisFlag As Integer = spedito_gratis(idVal, listino)

                ' Stesso formato di sempre: id,tcid,qta,ProdottoGratis
                listaArticoli.Add(String.Format("{0},{1},{2},{3}", idVal, tcIdVal, qta, prodottoGratisFlag))
            End If
        Next

        If listaArticoli.Count = 0 Then
            ' Nessun articolo selezionato: non faccio nulla
            Return
        End If

        ' Per compatibilità, imposto anche i campi "singolo" con il primo articolo
        Dim first As String = listaArticoli(0).ToString()
        Dim parts() As String = first.Split(","c)
        If parts.Length >= 3 Then
            Session("Carrello_ArticoloId") = parts(0)
            Session("Carrello_TCId") = parts(1)
            Session("Carrello_Quantita") = parts(2)
        End If

        Session("Carrello_SelezioneMultipla") = listaArticoli
        Session("ProdottoGratis") = 0 ' la logica puntuale è comunque nella lista
        Me.Response.Redirect("aggiungi.aspx")
    End Sub

    ' ============================
    ' HELPER PER LETTURA DATI DAL ROW
    ' ============================
    Private Function GetArticoloIdFromContainer(ByVal container As Control) As Integer
        Dim idVal As Integer = 0

        Dim lblId As Label = TryCast(container.FindControl("lblID"), Label)
        Dim lblId2 As Label = TryCast(container.FindControl("ID"), Label)
        Dim tbId As TextBox = TryCast(container.FindControl("tbID"), TextBox)
        Dim hfId As HiddenField = TryCast(container.FindControl("hfID"), HiddenField)
        Dim hfIdArt As HiddenField = TryCast(container.FindControl("hfIdArticolo"), HiddenField)

        If lblId IsNot Nothing Then
            Integer.TryParse(lblId.Text, idVal)
        ElseIf lblId2 IsNot Nothing Then
            Integer.TryParse(lblId2.Text, idVal)
        ElseIf tbId IsNot Nothing Then
            Integer.TryParse(tbId.Text, idVal)
        ElseIf hfId IsNot Nothing Then
            Integer.TryParse(hfId.Value, idVal)
        ElseIf hfIdArt IsNot Nothing Then
            Integer.TryParse(hfIdArt.Value, idVal)
        End If

        Return idVal
    End Function

    Private Function GetQuantitaFromContainer(ByVal container As Control) As Integer
        Dim qta As Integer = 1
        Dim qtaBox As TextBox = TryCast(container.FindControl("tbQuantita"), TextBox)
        If qtaBox IsNot Nothing Then
            If Not Integer.TryParse(qtaBox.Text, qta) OrElse qta <= 0 Then
                qta = 1
            End If
        End If
        Return qta
    End Function

    Private Function GetTCIdFromContainer(ByVal container As Control) As Integer
        Dim tcIdVal As Integer = -1
        Dim lblTC As Label = TryCast(container.FindControl("lblTCId"), Label)
        Dim hfTC As HiddenField = TryCast(container.FindControl("hfTCId"), HiddenField)

        If lblTC IsNot Nothing Then
            Integer.TryParse(lblTC.Text, tcIdVal)
        ElseIf hfTC IsNot Nothing Then
            Integer.TryParse(hfTC.Value, tcIdVal)
        End If

        Return tcIdVal
    End Function

    Public Function spedito_gratis(ByVal idArticolo As Integer, ByVal listino As Integer) As Integer
        Dim params As New Dictionary(Of String, Object)
        params.Add("@Listino", listino)
        params.Add("@IdArticolo", idArticolo)
        Dim dr = ExecuteQueryGetDataReader("SpedizioneGratis_Listini, SpedizioneGratis_Data_Inizio, SpedizioneGratis_Data_Fine, id",
                                           "articoli",
                                           "where (SpedizioneGratis_Listini LIKE CONCAT('%',@Listino, ';%')) AND (id = @IdArticolo) AND (SpedizioneGratis_Data_Inizio <= CURDATE()) AND (SpedizioneGratis_Data_Fine >= CURDATE())",
                                           params)
        If (dr.Count > 0) Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Protected Sub BT_Aggiungi_wishlist_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim ctrl As Control = TryCast(sender, Control)
        If ctrl Is Nothing Then Return

        Dim item As ListViewDataItem = TryCast(ctrl.NamingContainer, ListViewDataItem)
        If item Is Nothing Then Return

        Dim idVal As Integer = GetArticoloIdFromContainer(item)
        Dim tcIdVal As Integer = GetTCIdFromContainer(item)

        Dim idUtente As Integer = 0
        Integer.TryParse(Convert.ToString(Session.Item("UtentiId")), idUtente)

        If idUtente <= 0 OrElse idVal <= 0 Then
            ' Utente non loggato o ID articolo non valido: non faccio nulla
            Return
        End If

        Dim paramsSelect As New Dictionary(Of String, Object)
        paramsSelect.Add("@IdArticolo", idVal)
        paramsSelect.Add("@TcId", tcIdVal)
        paramsSelect.Add("@IdUtente", idUtente)

        Dim dr = ExecuteQueryGetDataReader("id", "wishlist",
                                           "where (id_articolo=@IdArticolo) AND (TCid=@TcId) AND (id_utente=@IdUtente)",
                                           paramsSelect)

        If (dr.Count <= 0) Then
            Dim paramsProcedure As New Dictionary(Of String, String)
            paramsProcedure.Add("?pIdUtente", idUtente.ToString())
            paramsProcedure.Add("?pIdArticolo", idVal.ToString())
            paramsProcedure.Add("?pTCid", tcIdVal.ToString())
            ExecuteStoredProcedure(paramsProcedure, "NewElement_Wishlist")
        End If
    End Sub

    Function controlla_abilitazione_settore(ByVal idArticolo As Integer) As Integer
        Dim params As New Dictionary(Of String, Object)
        params.Add("@VsuperarticoliId", idArticolo)
        Dim dr = ExecuteQueryGetDataReader("*", "vsuperarticoli",
                                           "INNER JOIN settori ON settori.id=vsuperarticoli.SettoriId WHERE (vsuperarticoli.id=@VsuperarticoliId) AND (settori.Abilitato=1)",
                                           params)
        If (dr.Count > 0) Then
            Return 1
        Else
            Return 0
        End If
    End Function

    Protected Sub CheckBoxMr_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        CheckBoxFilter_CheckedChanged(sender, e, "mr")
    End Sub

    Protected Sub CheckBoxSg_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        CheckBoxFilter_CheckedChanged(sender, e, "sg")
    End Sub

    Protected Sub CheckBoxTp_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        CheckBoxFilter_CheckedChanged(sender, e, "tp")
    End Sub

    Protected Sub CheckBoxGr_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        CheckBoxFilter_CheckedChanged(sender, e, "gr")
    End Sub

    Protected Sub CheckBoxFilter_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs, ByVal parName As String)
        Dim checkBox As CheckBox = sender
        Dim filterId As String = checkBox.Attributes("filterId")
        Dim queryString As String = Request.QueryString(parName)
        Dim parValue As String = String.Empty

        If checkBox.Checked = True Then
            If queryString <> String.Empty Then
                parValue = queryString & "|" & filterId
            Else
                parValue = filterId
            End If
        Else
            Dim ids As String() = queryString.Split("|"c)
            If ids.Length > 1 Then
                Dim filterIdArray As String() = filterId.Split("|"c)
                For Each id As String In ids
                    If Not Array.IndexOf(filterIdArray, id) >= 0 Then
                        parValue &= id & "|"
                    End If
                Next
                If parValue.Length > 0 Then
                    parValue = parValue.Substring(0, parValue.Length - 1)
                End If
            End If
        End If

        Dim newUrl As String = changeUrlGetParam(GetSafeReturnUrl(), parName, parValue)
        Response.Redirect(newUrl)
    End Sub

    Protected Sub Drop_Ordinamento_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Drop_Ordinamento.SelectedIndexChanged
        Session("Articoli_PageIndex") = 0
        Dim newUrl As String = changeUrlDependingFromDropDownList(GetSafeReturnUrl(), Drop_Ordinamento, "ordinamento")
        Response.Redirect(newUrl)
    End Sub

    Protected Sub Drop_Righe_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Drop_Righe.SelectedIndexChanged
        Dim pageSize As Integer = 12
        If Integer.TryParse(Drop_Righe.SelectedValue, pageSize) = False OrElse pageSize <= 0 Then
            pageSize = 12
        End If

        Session("RigheArticoli") = pageSize
        Session("Articoli_PageIndex") = 0
        ApplyPagerSettings(False)
    End Sub

    Protected Sub Drop_Filtra_Taglia_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Drop_Filtra_Taglia.SelectedIndexChanged
        Session("Articoli_PageIndex") = 0
        Dim newUrl As String = changeUrlDependingFromDropDownList(GetSafeReturnUrl(), Drop_Filtra_Taglia, "taglia")
        Response.Redirect(newUrl)
    End Sub

    Protected Sub Drop_Filtra_Colore_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Drop_Filtra_Colore.SelectedIndexChanged
        Session("Articoli_PageIndex") = 0
        Dim newUrl As String = changeUrlDependingFromDropDownList(GetSafeReturnUrl(), Drop_Filtra_Colore, "colore")
        Response.Redirect(newUrl)
    End Sub

    Protected Sub CheckBox_Disponibile_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_Disponibile.CheckedChanged
        Session("Articoli_PageIndex") = 0
        Dim newUrl As String = changeUrlDependingFromCheckBox(GetSafeReturnUrl(), CheckBox_Disponibile, "disponibile", "1", "")
        Response.Redirect(newUrl)
    End Sub
    Sub changeCheckBoxDependingFromUrl(ByVal checkBox As CheckBox, ByVal parName As String, ByVal parValueIfChecked As String)
        If Request.QueryString(parName) = parValueIfChecked Then
            checkBox.Checked = True
        Else
            checkBox.Checked = False
        End If
    End Sub

    Private Sub InitializeCatalogControlsFromRequest()
        changeCheckBoxDependingFromUrl(CheckBox_Disponibile, "disponibile", "1")
        changeDropDownListDependingFromUrl(Drop_Ordinamento, "ordinamento")

        Dim pageSize As Integer = 12
        If Session("RigheArticoli") IsNot Nothing Then
            Integer.TryParse(Convert.ToString(Session("RigheArticoli")), pageSize)
        End If
        If pageSize <= 0 Then pageSize = 12
        SelectDropDownValueSafe(Drop_Righe, pageSize.ToString())
    End Sub

    Function changeUrlDependingFromCheckBox(ByVal url As String,
                                            ByVal checkBox As CheckBox,
                                            ByVal parName As String,
                                            ByVal parValueIfChecked As String,
                                            ByVal parValueIfNotChecked As String) As String
        Dim newUrl As String
        If checkBox.Checked = True Then
            newUrl = changeUrlGetParam(url, parName, parValueIfChecked)
        Else
            newUrl = changeUrlGetParam(url, parName, parValueIfNotChecked)
        End If
        Return newUrl
    End Function

    Sub changeDropDownListDependingFromUrl(ByVal dropDownList As DropDownList, ByVal parName As String)
        If dropDownList Is Nothing Then Exit Sub

        Dim raw As String = Convert.ToString(Request.QueryString(parName))
        If String.IsNullOrEmpty(raw) Then Exit Sub

        Dim value As String = raw
        Dim parts As String() = raw.Split("|"c)
        If parts.Length > 1 Then value = parts(1)

        SelectDropDownValueSafe(dropDownList, value)
    End Sub

    Function changeUrlDependingFromDropDownList(ByVal url As String,
                                                ByVal dropDownList As DropDownList,
                                                ByVal parName As String) As String
        If dropDownList Is Nothing OrElse String.IsNullOrEmpty(dropDownList.SelectedValue) Then
            Return changeUrlGetParam(url, parName, String.Empty)
        End If
        Return changeUrlGetParam(url, parName, dropDownList.SelectedIndex & "|" & dropDownList.SelectedValue)
    End Function

    Function changeUrlGetParam(ByVal url As String, ByVal parName As String, ByVal parValue As String) As String
        If String.IsNullOrEmpty(url) Then url = GetSafeReturnUrl()
        If String.IsNullOrEmpty(parName) Then Return url

        Dim anchor As String = String.Empty
        Dim hashIndex As Integer = url.IndexOf("#"c)
        If hashIndex >= 0 Then
            anchor = url.Substring(hashIndex)
            url = url.Substring(0, hashIndex)
        End If

        Dim baseUrl As String = url
        Dim rawQuery As String = String.Empty
        Dim queryIndex As Integer = url.IndexOf("?"c)
        If queryIndex >= 0 Then
            baseUrl = url.Substring(0, queryIndex)
            rawQuery = url.Substring(queryIndex + 1)
        End If

        Dim qs = HttpUtility.ParseQueryString(rawQuery)
        If String.IsNullOrEmpty(parValue) Then
            qs.Remove(parName)
        Else
            qs(parName) = parValue
        End If

        qs.Remove("page")
        qs.Remove("pg")
        qs.Remove("p")
        qs.Remove("rimuovi")

        Dim newQuery As String = qs.ToString()
        If String.IsNullOrEmpty(newQuery) Then Return baseUrl & anchor
        Return baseUrl & "?" & newQuery & anchor
    End Function

    Private Sub SelectDropDownValueSafe(ByVal list As DropDownList, ByVal value As String)
        If list Is Nothing Then Exit Sub
        If value Is Nothing Then value = String.Empty

        Dim item As ListItem = list.Items.FindByValue(value)
        If item Is Nothing AndAlso value <> String.Empty Then
            item = list.Items.FindByValue(String.Empty)
        End If
        If item Is Nothing AndAlso list.Items.Count > 0 Then
            item = list.Items(0)
        End If

        If item IsNot Nothing Then
            list.ClearSelection()
            item.Selected = True
        End If
    End Sub

    Private Function GetSafeReturnUrl() As String
        If Request Is Nothing OrElse Request.Url Is Nothing Then Return "articoli.aspx"
        Return Request.Url.AbsoluteUri
    End Function

    Protected Sub rptActiveFilters_ItemCommand(ByVal source As Object, ByVal e As RepeaterCommandEventArgs)
        If String.Equals(e.CommandName, "remove", StringComparison.OrdinalIgnoreCase) Then
            Session("Articoli_PageIndex") = 0
            Response.Redirect(RemoveActiveFilterFromUrl(GetSafeReturnUrl(), Convert.ToString(e.CommandArgument)))
        End If
    End Sub

    Protected Sub lbClearAllFilters_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Session("Articoli_PageIndex") = 0
        Response.Redirect(ClearCatalogFiltersFromUrl(GetSafeReturnUrl()))
    End Sub

    Private Sub BindActiveFilters()
        Dim active As New List(Of ActiveFilterItem)()

        Dim q As String = QS("q", 80)
        If q <> "" Then AddActiveFilter(active, "q=", "Ricerca: " & q)

        If Request.QueryString("disponibile") = "1" Then
            AddActiveFilter(active, "disponibile=", "Solo disponibili")
        End If

        If Request.QueryString("inpromo") = "1" Then
            AddActiveFilter(active, "inpromo=", "In offerta")
        End If

        If Request.QueryString("spedgratis") = "1" Then
            AddActiveFilter(active, "spedgratis=", "Spedizione gratis")
        End If

        AddFacetActiveFilters(active, "tp", "Tipologia", "tipologie")
        AddFacetActiveFilters(active, "gr", "Categoria", "Gruppi")
        AddFacetActiveFilters(active, "sg", "Sottocategoria", "SottoGruppi")
        AddFacetActiveFilters(active, "mr", "Marca", "Marche")

        Dim rawSort As String = Convert.ToString(Request.QueryString("ordinamento"))
        If rawSort <> "" AndAlso Drop_Ordinamento IsNot Nothing AndAlso Drop_Ordinamento.SelectedItem IsNot Nothing AndAlso Drop_Ordinamento.SelectedValue <> "" Then
            AddActiveFilter(active, "ordinamento=", "Ordina: " & Drop_Ordinamento.SelectedItem.Text)
        End If

        AddVariantActiveFilter(active, "taglia", "Taglia", Drop_Filtra_Taglia)
        AddVariantActiveFilter(active, "colore", "Colore", Drop_Filtra_Colore)

        If rptActiveFilters IsNot Nothing Then
            rptActiveFilters.DataSource = active
            rptActiveFilters.DataBind()
        End If

        If ksActiveFilters IsNot Nothing Then ksActiveFilters.Visible = (active.Count > 0)
        If lbClearAllFilters IsNot Nothing Then lbClearAllFilters.Visible = (active.Count > 1)
    End Sub

    Private Sub AddActiveFilter(ByVal list As List(Of ActiveFilterItem), ByVal key As String, ByVal label As String)
        If list Is Nothing OrElse String.IsNullOrEmpty(label) Then Exit Sub
        Dim item As New ActiveFilterItem()
        item.Key = key
        item.Label = ThemeManager.CompactText(label, 70)
        list.Add(item)
    End Sub

    Private Sub AddFacetActiveFilters(ByVal active As List(Of ActiveFilterItem), ByVal parName As String, ByVal title As String, ByVal tableName As String)
        Dim csv As String = SafeIdListFromQuery(parName)
        If String.IsNullOrEmpty(csv) Then Exit Sub

        Dim labels As Dictionary(Of Integer, String) = LookupCatalogDescriptions(tableName, csv)
        For Each rawId As String In csv.Split(","c)
            Dim id As Integer = 0
            If Not Integer.TryParse(rawId, id) OrElse id <= 0 Then Continue For

            Dim text As String = id.ToString()
            If labels IsNot Nothing AndAlso labels.ContainsKey(id) Then text = labels(id)
            AddActiveFilter(active, parName & "=" & id.ToString(), title & ": " & text)
        Next
    End Sub

    Private Sub AddVariantActiveFilter(ByVal active As List(Of ActiveFilterItem), ByVal parName As String, ByVal title As String, ByVal list As DropDownList)
        Dim raw As String = Convert.ToString(Request.QueryString(parName))
        If String.IsNullOrEmpty(raw) Then Exit Sub

        Dim text As String = ""
        If list IsNot Nothing AndAlso list.SelectedItem IsNot Nothing AndAlso list.SelectedValue <> "0" Then
            text = list.SelectedItem.Text
        End If

        If text = "" Then
            Dim parts As String() = raw.Split("|"c)
            If parts.Length > 1 Then text = parts(1) Else text = raw
        End If

        If text <> "" Then AddActiveFilter(active, parName & "=", title & ": " & text)
    End Sub

    Private Function LookupCatalogDescriptions(ByVal tableName As String, ByVal idsCsv As String) As Dictionary(Of Integer, String)
        Dim result As New Dictionary(Of Integer, String)()
        If String.IsNullOrEmpty(idsCsv) Then Return result

        Dim safeTable As String = ""
        Select Case tableName
            Case "tipologie"
                safeTable = "tipologie"
            Case "Gruppi"
                safeTable = "Gruppi"
            Case "SottoGruppi"
                safeTable = "SottoGruppi"
            Case "Marche"
                safeTable = "Marche"
            Case Else
                Return result
        End Select

        Dim placeholders As New List(Of String)()
        Dim params As New Dictionary(Of String, Object)()
        Dim i As Integer = 0
        For Each rawId As String In idsCsv.Split(","c)
            Dim id As Integer = 0
            If Not Integer.TryParse(rawId, id) OrElse id <= 0 Then Continue For
            Dim pName As String = "@id" & i.ToString()
            placeholders.Add(pName)
            params.Add(pName, id)
            i += 1
        Next

        If placeholders.Count = 0 Then Return result

        Try
            Dim rows = ExecuteQueryGetDataReader("id, Descrizione", safeTable, "WHERE id IN (" & String.Join(",", placeholders.ToArray()) & ")", params)
            For Each row As Dictionary(Of String, Object) In rows
                Dim id As Integer = 0
                If row.ContainsKey("id") Then Integer.TryParse(Convert.ToString(row("id")), id)
                If id <= 0 Then Continue For

                Dim descrizione As String = ""
                If row.ContainsKey("Descrizione") Then descrizione = Convert.ToString(row("Descrizione"))
                If descrizione <> "" AndAlso Not result.ContainsKey(id) Then result.Add(id, descrizione)
            Next
        Catch
            ' I badge dei filtri non devono mai bloccare il catalogo.
        End Try

        Return result
    End Function

    Private Function RemoveActiveFilterFromUrl(ByVal url As String, ByVal filterKey As String) As String
        If String.IsNullOrEmpty(url) Then url = GetSafeReturnUrl()
        If String.IsNullOrEmpty(filterKey) Then Return url

        Dim paramName As String = filterKey
        Dim paramValue As String = ""
        Dim sepIndex As Integer = filterKey.IndexOf("="c)
        If sepIndex >= 0 Then
            paramName = filterKey.Substring(0, sepIndex)
            paramValue = filterKey.Substring(sepIndex + 1)
        End If

        Dim qs = ParseUrlQuery(url)
        If String.IsNullOrEmpty(paramName) Then Return url

        If String.IsNullOrEmpty(paramValue) Then
            qs.Remove(paramName)
        Else
            Dim current As String = Convert.ToString(qs(paramName))
            Dim remaining As New List(Of String)()
            For Each part As String In current.Split("|"c)
                If part <> "" AndAlso Not String.Equals(part, paramValue, StringComparison.OrdinalIgnoreCase) Then
                    remaining.Add(part)
                End If
            Next

            If remaining.Count = 0 Then
                qs.Remove(paramName)
            Else
                qs(paramName) = String.Join("|", remaining.ToArray())
            End If
        End If

        qs.Remove("rimuovi")
        qs.Remove("page")
        qs.Remove("pg")
        qs.Remove("p")
        Return BuildUrlWithQuery(url, qs)
    End Function

    Private Function ClearCatalogFiltersFromUrl(ByVal url As String) As String
        Dim qs = ParseUrlQuery(url)
        Dim keysToRemove As String() = New String() {"q", "tp", "gr", "sg", "mr", "disponibile", "inpromo", "spedgratis", "ordinamento", "taglia", "colore", "rimuovi", "page", "pg", "p"}
        For Each key As String In keysToRemove
            qs.Remove(key)
        Next
        Return BuildUrlWithQuery(url, qs)
    End Function

    Private Function ParseUrlQuery(ByVal url As String) As System.Collections.Specialized.NameValueCollection
        If String.IsNullOrEmpty(url) Then url = GetSafeReturnUrl()

        Dim rawQuery As String = ""
        Dim hashIndex As Integer = url.IndexOf("#"c)
        If hashIndex >= 0 Then url = url.Substring(0, hashIndex)

        Dim queryIndex As Integer = url.IndexOf("?"c)
        If queryIndex >= 0 Then rawQuery = url.Substring(queryIndex + 1)
        Return HttpUtility.ParseQueryString(rawQuery)
    End Function

    Private Function BuildUrlWithQuery(ByVal url As String, ByVal qs As System.Collections.Specialized.NameValueCollection) As String
        If String.IsNullOrEmpty(url) Then url = GetSafeReturnUrl()

        Dim anchor As String = ""
        Dim hashIndex As Integer = url.IndexOf("#"c)
        If hashIndex >= 0 Then
            anchor = url.Substring(hashIndex)
            url = url.Substring(0, hashIndex)
        End If

        Dim baseUrl As String = url
        Dim queryIndex As Integer = url.IndexOf("?"c)
        If queryIndex >= 0 Then baseUrl = url.Substring(0, queryIndex)

        Dim newQuery As String = ""
        If qs IsNot Nothing Then newQuery = qs.ToString()
        If String.IsNullOrEmpty(newQuery) Then Return baseUrl & anchor
        Return baseUrl & "?" & newQuery & anchor
    End Function

    Sub alert(ByVal message As String)
        Dim safeMsg As String = System.Web.HttpUtility.JavaScriptStringEncode(Convert.ToString(message))
        Dim myScript As String = "window.alert('" & safeMsg & "');"
        ClientScript.RegisterStartupScript(Me.GetType(), "myScript", myScript, True)
    End Sub


    Function getCorrectLengthDescription(ByVal description As String) As String
        Dim s As String = Convert.ToString(description)
        If s IsNot Nothing AndAlso s.Length > 28 Then
            s = s.Substring(0, 26) & "..."
        End If
        Return H(s)
    End Function

    ' *** GESTIONE IMMAGINI PRODOTTO ***
    ' Usa la cartella pubblica ~/Public/images/articoli/ e la fallback ~/Public/images/nofoto.gif
    Public Function checkImg(ParamArray args() As Object) As String
        Dim fileName As String = ""

        If args IsNot Nothing AndAlso args.Length > 0 AndAlso
           args(0) IsNot Nothing AndAlso Not Convert.IsDBNull(args(0)) Then

            fileName = Convert.ToString(args(0)).Trim()
        End If

        ' Nessun valore: uso la nofoto
        If String.IsNullOrEmpty(fileName) Then
            Return ThemeManager.PlaceholderProductImageUrl()
        End If

        ' Se è già un path completo, non lo tocchiamo
        If fileName.StartsWith("~") OrElse fileName.StartsWith("/") Then
            Dim resolvedFileName As String = IO.Path.GetFileName(fileName.Replace("\", "/"))
            If String.IsNullOrWhiteSpace(resolvedFileName) Then Return ThemeManager.PlaceholderProductImageUrl()
            Return "~/Public/assets/images/articoli/" & resolvedFileName
        End If

        ' Nome file "nudo": lo mettiamo nella cartella pubblica articoli
        Dim finalFileName As String = IO.Path.GetFileName(fileName.Replace("\", "/"))
        If String.IsNullOrWhiteSpace(finalFileName) Then Return ThemeManager.PlaceholderProductImageUrl()
        Return "~/Public/assets/images/articoli/" & finalFileName
    End Function

    ' Lista sicura di ID da QueryString (mr / tp / gr / sg)
    Private Function SafeIdListFromQuery(ByVal parName As String) As String
        Dim raw As String = Request.QueryString(parName)
        If String.IsNullOrEmpty(raw) Then
            Return String.Empty
        End If

        Dim parts As String() = raw.Split("|"c)
        Dim validIds As New List(Of String)()

        For Each p As String In parts
            If Not String.IsNullOrWhiteSpace(p) Then
                Dim id As Integer
                If Integer.TryParse(p.Trim(), id) AndAlso id > 0 Then
                    validIds.Add(id.ToString())
                End If
            End If
        Next

        If validIds.Count = 0 Then
            Return String.Empty
        End If

        Return String.Join(",", validIds)
    End Function

    '==========================================================
    ' STEP 27 (SEO): noindex/canonical per faccette catalogo
    ' Parametri SEO consentiti: st, ct, tp, gr, sg, mr
    ' Regola pratica (anti-crawl-bloat):
    '   - INDEX se (st+ct) presenti e:
    '       * tp singolo (default) + (nessun altro filtro), oppure
    '       * tp singolo + 1 solo filtro tra mr/gr/sg (singolo), oppure
    '       * tp singolo + coppia gerarchica gr+sg (singoli)
    '   - NOINDEX per multiselezione (id multipli) e per combinazioni multiple (es. mr+gr, mr+sg, mr+gr+sg, ecc.)
    '   - NOINDEX se sono presenti altri parametri (q, pid, ordinamento, disponibile, taglia, colore, ...)
    '==========================================================
    Private Sub ApplySeoIndexPolicy()
        Try
            If litSeoHead Is Nothing Then Exit Sub

            Dim basePath As String = Request.Url.GetLeftPart(UriPartial.Path)

            Dim stId As Integer = GetQsIntSafe("st")
            Dim ctId As Integer = GetQsIntSafe("ct")
            Dim tpIds As List(Of Integer) = GetQsIdListSafe("tp")
            Dim grIds As List(Of Integer) = GetQsIdListSafe("gr")
            Dim sgIds As List(Of Integer) = GetQsIdListSafe("sg")
            Dim mrIds As List(Of Integer) = GetQsIdListSafe("mr")

            Dim allowIndex As Boolean = IsSeoIndexAllowed(stId, ctId, tpIds, grIds, sgIds, mrIds)

            Dim canonical As String = BuildSeoCanonicalUrl(basePath, allowIndex, stId, ctId, tpIds, grIds, sgIds, mrIds)
            Dim robots As String = If(allowIndex, "index,follow", "noindex,follow")

            Dim sb As New StringBuilder()
            sb.Append("<link rel=""canonical"" href=""")
            sb.Append(HttpUtility.HtmlAttributeEncode(canonical))
            sb.Append(""" />").Append(vbCrLf)
            sb.Append("<meta name=""robots"" content=""")
            sb.Append(robots)
            sb.Append(""" />").Append(vbCrLf)

            litSeoHead.Text = sb.ToString()

            If Not allowIndex Then
                Try
                    Response.AddHeader("X-Robots-Tag", "noindex,follow")
                Catch
                    'ignore
                End Try
            End If
        Catch
            'non blocca la pagina
        End Try
    End Sub

    Private Function IsSeoIndexAllowed(ByVal stId As Integer,
                                      ByVal ctId As Integer,
                                      ByVal tpIds As List(Of Integer),
                                      ByVal grIds As List(Of Integer),
                                      ByVal sgIds As List(Of Integer),
                                      ByVal mrIds As List(Of Integer)) As Boolean
        ' st/ct obbligatori
        If stId <= 0 OrElse ctId <= 0 Then Return False

        ' Se ci sono parametri extra (diversi da st/ct/tp/gr/sg/mr) => NOINDEX
        Try
            For Each k As String In Request.QueryString.AllKeys
                If String.IsNullOrEmpty(k) Then Continue For
                Dim keyLower As String = k.ToLowerInvariant()
                If keyLower = "st" OrElse keyLower = "ct" OrElse keyLower = "tp" OrElse keyLower = "gr" OrElse keyLower = "sg" OrElse keyLower = "mr" Then
                    Continue For
                End If
                Dim v As String = Convert.ToString(Request.QueryString(k))
                If Not String.IsNullOrEmpty(v) Then
                    Return False
                End If
            Next
        Catch
            Return False
        End Try

        ' Multi-selezione => NOINDEX
        If tpIds IsNot Nothing AndAlso tpIds.Count > 1 Then Return False
        If grIds IsNot Nothing AndAlso grIds.Count > 1 Then Return False
        If sgIds IsNot Nothing AndAlso sgIds.Count > 1 Then Return False
        If mrIds IsNot Nothing AndAlso mrIds.Count > 1 Then Return False

        Dim hasTp As Boolean = (tpIds IsNot Nothing AndAlso tpIds.Count = 1)
        Dim hasGr As Boolean = (grIds IsNot Nothing AndAlso grIds.Count = 1)
        Dim hasSg As Boolean = (sgIds IsNot Nothing AndAlso sgIds.Count = 1)
        Dim hasMr As Boolean = (mrIds IsNot Nothing AndAlso mrIds.Count = 1)

        Dim activeCount As Integer = 0
        If hasTp Then activeCount += 1
        If hasGr Then activeCount += 1
        If hasSg Then activeCount += 1
        If hasMr Then activeCount += 1

        ' (st+ct) e nessuna faccetta => INDEX
        If activeCount = 0 Then Return True

        ' Solo una faccetta singola => INDEX
        If activeCount = 1 Then Return True

        ' tp + 1 sola faccetta => INDEX
        If hasTp AndAlso activeCount = 2 Then
            ' tp + mr  | tp + gr | tp + sg
            If hasMr AndAlso Not hasGr AndAlso Not hasSg Then Return True
            If hasGr AndAlso Not hasMr AndAlso Not hasSg Then Return True
            If hasSg AndAlso Not hasMr AndAlso Not hasGr Then Return True
        End If

        ' tp + gr + sg (coppia gerarchica) => INDEX
        If hasTp AndAlso hasGr AndAlso hasSg AndAlso Not hasMr Then
            If activeCount = 3 Then Return True
        End If

        Return False
    End Function

    Private Function BuildSeoCanonicalUrl(ByVal basePath As String,
                                         ByVal allowIndex As Boolean,
                                         ByVal stId As Integer,
                                         ByVal ctId As Integer,
                                         ByVal tpIds As List(Of Integer),
                                         ByVal grIds As List(Of Integer),
                                         ByVal sgIds As List(Of Integer),
                                         ByVal mrIds As List(Of Integer)) As String

        Dim parts As New List(Of String)

        If stId > 0 Then parts.Add("st=" & stId.ToString())
        If ctId > 0 Then parts.Add("ct=" & ctId.ToString())

        ' tp è considerato parte della navigazione base (se singolo)
        If tpIds IsNot Nothing AndAlso tpIds.Count = 1 Then
            parts.Add("tp=" & tpIds(0).ToString())
        End If

        If allowIndex Then
            Dim hasTp As Boolean = (tpIds IsNot Nothing AndAlso tpIds.Count = 1)
            Dim hasGr As Boolean = (grIds IsNot Nothing AndAlso grIds.Count = 1)
            Dim hasSg As Boolean = (sgIds IsNot Nothing AndAlso sgIds.Count = 1)
            Dim hasMr As Boolean = (mrIds IsNot Nothing AndAlso mrIds.Count = 1)

            ' tp + gr + sg
            If hasTp AndAlso hasGr AndAlso hasSg AndAlso Not hasMr Then
                parts.Add("gr=" & grIds(0).ToString())
                parts.Add("sg=" & sgIds(0).ToString())
            Else
                ' tp + 1 sola faccetta
                If hasMr AndAlso Not hasGr AndAlso Not hasSg Then
                    parts.Add("mr=" & mrIds(0).ToString())
                ElseIf hasGr AndAlso Not hasMr AndAlso Not hasSg Then
                    parts.Add("gr=" & grIds(0).ToString())
                ElseIf hasSg AndAlso Not hasMr AndAlso Not hasGr Then
                    parts.Add("sg=" & sgIds(0).ToString())
                End If
            End If
        End If

        If parts.Count = 0 Then
            Return basePath
        End If

        Return basePath & "?" & String.Join("&", parts.ToArray())
    End Function

    Private Function GetQsIntSafe(ByVal name As String) As Integer
        Dim v As Integer = 0
        Try
            Integer.TryParse(Convert.ToString(Request.QueryString(name)), v)
        Catch
            v = 0
        End Try
        If v < 0 Then v = 0
        Return v
    End Function

    Private Function GetQsIdListSafe(ByVal name As String) As List(Of Integer)
        Dim list As New List(Of Integer)
        Try
            Dim raw As String = Convert.ToString(Request.QueryString(name))
            If String.IsNullOrEmpty(raw) Then Return list

            Dim parts As String() = raw.Split(New Char() {"|"c, ","c}, StringSplitOptions.RemoveEmptyEntries)
            Dim seen As New Dictionary(Of Integer, Boolean)()

            For Each p As String In parts
                Dim id As Integer = 0
                If Integer.TryParse(p.Trim(), id) AndAlso id > 0 Then
                    If Not seen.ContainsKey(id) Then
                        seen.Add(id, True)
                        list.Add(id)
                    End If
                End If
            Next
        Catch
            'ignore
        End Try
        Return list
    End Function

    '==========================================================
    ' STEP 3 (CATALOGO): st/ct/tp defaults + Session sync
    '==========================================================
    Private Sub EnsureCatalogQueryDefaults()
        Try
            Dim pid As Integer = 0
            Integer.TryParse(Request.QueryString("pid"), pid)

            Dim q As String = QS("q", 80)
            If pid > 0 OrElse Not String.IsNullOrEmpty(q) Then
                ' Dettaglio prodotto o ricerca libera: non forziamo default di navigazione
                Exit Sub
            End If

            Dim stId As Integer = 0
            Dim ctId As Integer = 0
            Integer.TryParse(Request.QueryString("st"), stId)
            Integer.TryParse(Request.QueryString("ct"), ctId)

            Dim tpRaw As String = Convert.ToString(Request.QueryString("tp"))
            Dim tpCanonical As String = tpRaw

            Dim needRedirect As Boolean = False

            ' 1) Se ho ct ma st mancante o incoerente, ricavo st dalla categoria (tabelle reali)
            If ctId > 0 Then
                Dim stFromCat As Integer = LookupSettoreIdByCategoria(ctId)
                If stFromCat > 0 AndAlso (stId <= 0 OrElse stId <> stFromCat) Then
                    stId = stFromCat
                    needRedirect = True
                End If
            End If

            ' 2) Se ho st ma ct mancante, prendo una categoria di default del settore
            If stId > 0 AndAlso ctId <= 0 Then
                Dim defaultCt As Integer = LookupDefaultCategoriaIdBySettore(stId)
                If defaultCt > 0 Then
                    ctId = defaultCt
                    needRedirect = True
                End If
            End If

            ' 3) Se manca tp ma ho ct, prendo una tipologia di default della categoria
            If String.IsNullOrEmpty(tpRaw) AndAlso ctId > 0 Then
                Dim defaultTp As Integer = LookupDefaultTipologiaIdByCategoria(ctId)
                If defaultTp > 0 Then
                    tpCanonical = defaultTp.ToString()
                    needRedirect = True
                End If
            End If

            ' 4) Redirect solo se ho completato / corretto i parametri base di navigazione
            If needRedirect Then
                Dim dict As New Dictionary(Of String, String)(StringComparer.OrdinalIgnoreCase)

                For Each k As String In Request.QueryString.AllKeys
                    If String.IsNullOrEmpty(k) Then Continue For
                    dict(k) = Request.QueryString(k)
                Next

                If stId > 0 Then
                    dict("st") = stId.ToString()
                ElseIf dict.ContainsKey("st") Then
                    dict.Remove("st")
                End If

                If ctId > 0 Then
                    dict("ct") = ctId.ToString()
                ElseIf dict.ContainsKey("ct") Then
                    dict.Remove("ct")
                End If

                If Not String.IsNullOrEmpty(tpCanonical) Then
                    dict("tp") = tpCanonical
                ElseIf dict.ContainsKey("tp") Then
                    dict.Remove("tp")
                End If

                Dim qs As String = BuildQueryString(dict)
                Dim url As String = Request.Path
                If Not String.IsNullOrEmpty(qs) Then
                    url &= "?" & qs
                End If

                Response.Redirect(url, True)
            End If

        Catch
            'non blocca la pagina: se non riesco a determinare default, proseguo
        End Try
    End Sub

    Private Sub SyncCatalogSessionFromQuery()
        Try
            Dim stId As Integer = 0
            Dim ctId As Integer = 0
            Integer.TryParse(Request.QueryString("st"), stId)
            Integer.TryParse(Request.QueryString("ct"), ctId)

            ' Se manca st ma ho ct, ricavo st per far funzionare i datasource (tipologie, ecc.)
            If stId <= 0 AndAlso ctId > 0 Then
                stId = LookupSettoreIdByCategoria(ctId)
            End If

            If stId > 0 Then
                Session("st") = stId
            End If

            If ctId > 0 Then
                Session("ct") = ctId
            End If

        Catch
            'silent
        End Try
    End Sub

    Private Function BuildQueryString(ByVal dict As Dictionary(Of String, String)) As String
        If dict Is Nothing OrElse dict.Count = 0 Then Return String.Empty

        Dim ordered As New List(Of String)

        If dict.ContainsKey("st") Then ordered.Add("st")
        If dict.ContainsKey("ct") Then ordered.Add("ct")
        If dict.ContainsKey("tp") Then ordered.Add("tp")

        Dim rest As New List(Of String)
        For Each k As String In dict.Keys
            If String.Equals(k, "st", StringComparison.OrdinalIgnoreCase) Then Continue For
            If String.Equals(k, "ct", StringComparison.OrdinalIgnoreCase) Then Continue For
            If String.Equals(k, "tp", StringComparison.OrdinalIgnoreCase) Then Continue For
            rest.Add(k)
        Next
        rest.Sort()
        ordered.AddRange(rest)

        Dim sb As New StringBuilder()
        For Each k As String In ordered
            Dim v As String = dict(k)
            If String.IsNullOrEmpty(k) Then Continue For
            If v Is Nothing Then v = String.Empty

            If sb.Length > 0 Then sb.Append("&")
            sb.Append(HttpUtility.UrlEncode(k))
            sb.Append("=")
            sb.Append(HttpUtility.UrlEncode(v))
        Next

        Return sb.ToString()
    End Function

    Private Function LookupSettoreIdByCategoria(ByVal categoriaId As Integer) As Integer
        If categoriaId <= 0 Then Return 0
        Try
            Dim connStr As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            Using conn As New MySqlConnection(connStr)
                conn.Open()
                Using cmd As New MySqlCommand("SELECT Id_settore FROM categorie WHERE id=@id LIMIT 1", conn)
                    cmd.Parameters.Add("@id", MySqlDbType.Int32).Value = categoriaId
                    Dim obj As Object = cmd.ExecuteScalar()
                    If obj Is Nothing OrElse obj Is DBNull.Value Then Return 0
                    Dim st As Integer = 0
                    Integer.TryParse(Convert.ToString(obj), st)
                    Return st
                End Using
            End Using
        Catch
            Return 0
        End Try
    End Function

    Private Function LookupDefaultCategoriaIdBySettore(ByVal settoreId As Integer) As Integer
        If settoreId <= 0 Then Return 0
        Try
            Dim connStr As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            Using conn As New MySqlConnection(connStr)
                conn.Open()
                Using cmd As New MySqlCommand("SELECT id FROM categorie WHERE Abilitato=1 AND Id_settore=@st ORDER BY Ordinamento, Descrizione, id LIMIT 1", conn)
                    cmd.Parameters.Add("@st", MySqlDbType.Int32).Value = settoreId
                    Dim obj As Object = cmd.ExecuteScalar()
                    If obj Is Nothing OrElse obj Is DBNull.Value Then Return 0
                    Dim ct As Integer = 0
                    Integer.TryParse(Convert.ToString(obj), ct)
                    Return ct
                End Using
            End Using
        Catch
            Return 0
        End Try
    End Function

    Private Function LookupDefaultTipologiaIdByCategoria(ByVal categoriaId As Integer) As Integer
        If categoriaId <= 0 Then Return 0
        Try
            Dim connStr As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            Using conn As New MySqlConnection(connStr)
                conn.Open()
                Using cmd As New MySqlCommand("SELECT id FROM tipologie WHERE Abilitato=1 AND Id_categoria=@ct ORDER BY Ordinamento, Descrizione, id LIMIT 1", conn)
                    cmd.Parameters.Add("@ct", MySqlDbType.Int32).Value = categoriaId
                    Dim obj As Object = cmd.ExecuteScalar()
                    If obj Is Nothing OrElse obj Is DBNull.Value Then Return 0
                    Dim tp As Integer = 0
                    Integer.TryParse(Convert.ToString(obj), tp)
                    Return tp
                End Using
            End Using
        Catch
            Return 0
        End Try
    End Function



    Function getFilterIds(ByVal parName As String) As String()
        If Not String.IsNullOrEmpty(Request.QueryString(parName)) Then
            Return Request.QueryString(parName).Split("|"c)
        Else
            Dim result(0) As String
            Return result
        End If
    End Function

    Function addIds(ByVal filterIds As String, ByVal idsToAdd As String) As String
        Dim result As String = filterIds
        Dim filterIdsArray As String() = filterIds.Split("|"c)
        Dim idsToAddArray As String() = idsToAdd.Split("|"c)
        For Each id As String In idsToAddArray
            If Not Array.IndexOf(filterIdsArray, id) >= 0 Then
                result = result & "|" & id
            End If
        Next
        Return result
    End Function

    Function filterIdsContains(ByVal parName As String, ByVal ids As String) As Boolean
        If Not String.IsNullOrEmpty(Request.QueryString(parName)) Then
            Dim queryStringIds = Request.QueryString(parName).Split("|"c)
            Dim idsArray = ids.Split("|"c)
            For Each id As String In idsArray
                If Array.IndexOf(queryStringIds, id) >= 0 Then
                    If filters.ContainsKey(parName) Then
                        filters.Item(parName) = addIds(filters.Item(parName), ids)
                    Else
                        filters.Add(parName, ids)
                    End If
                    Return True
                End If
            Next
            Return False
        Else
            Return False
        End If
    End Function

    Protected Function ExecuteQueryGetDataSet(ByVal fields As String,
                                              ByVal table As String,
                                              Optional ByVal wherePart As String = "",
                                              Optional ByVal params As Dictionary(Of String, String) = Nothing) As DataSet
        Dim sqlString As String = "SELECT " & fields & " FROM " & table & " " & wherePart
        Dim ds As New DataSet()
        Dim conn As New MySqlConnection

        Try
            Dim connectionString As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            If Not connectionString Is Nothing Then
                conn.ConnectionString = connectionString
                conn.Open()
                Dim cmd = New MySqlCommand With {
                    .Connection = conn,
                    .CommandType = CommandType.Text,
                    .CommandText = sqlString
                }
                If Not params Is Nothing Then
                    For Each paramName In params.Keys
                        cmd.Parameters.AddWithValue(paramName, params(paramName))
                    Next
                End If
                Dim sqlAdp As New MySqlDataAdapter(cmd)
                sqlAdp.Fill(ds, table)
                sqlAdp.Dispose()
                cmd.Dispose()
            End If
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
                conn.Dispose()
            End If
        End Try

        Return ds
    End Function

    Protected Function ExecuteQueryGetDataReader(ByVal fields As String,
                                                 ByVal table As String,
                                                 Optional ByVal wherePart As String = "",
                                                 Optional ByVal params As Dictionary(Of String, Object) = Nothing) As List(Of Dictionary(Of String, Object))
        Dim sqlString As String = "SELECT " & fields & " FROM " & table & " " & wherePart
        Dim result As New List(Of Dictionary(Of String, Object))()
        Dim conn As New MySqlConnection

        Try
            Dim connectionString As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            If Not connectionString Is Nothing Then
                conn.ConnectionString = connectionString
                conn.Open()
                Dim cmd = New MySqlCommand With {
                    .Connection = conn,
                    .CommandType = CommandType.Text,
                    .CommandText = sqlString
                }
                If Not params Is Nothing Then
                    For Each paramName In params.Keys
                        cmd.Parameters.AddWithValue(paramName, params(paramName))
                    Next
                End If

                Using dr As MySqlDataReader = cmd.ExecuteReader()
                    While dr.Read()
                        Dim row As New Dictionary(Of String, Object)()
                        For i As Integer = 0 To dr.FieldCount - 1
                            Dim columnName As String = dr.GetName(i)
                            Dim value As Object = dr.GetValue(i)
                            If Not row.ContainsKey(columnName) Then
                                row.Add(columnName, value)
                            End If
                        Next
                        result.Add(row)
                    End While
                End Using

                conn.Close()
            End If
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
                conn.Dispose()
            End If
        End Try

        Return result
    End Function

    Protected Function ExecuteInsert(ByVal fields As String,
                                     ByVal table As String,
                                     Optional ByVal values As String = "",
                                     Optional ByVal params As Dictionary(Of String, Object) = Nothing)
        Dim sqlString As String = "INSERT INTO " & table & " (" & fields & ") VALUES (" & values & ")"
        Dim conn As New MySqlConnection

        Try
            Dim connectionString As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            If Not connectionString Is Nothing Then
                conn.ConnectionString = connectionString
                conn.Open()
                Dim cmd = New MySqlCommand With {
                    .Connection = conn,
                    .CommandType = CommandType.Text,
                    .CommandText = sqlString
                }
                If params IsNot Nothing Then
                    For Each paramName In params.Keys
                        cmd.Parameters.AddWithValue(paramName, params(paramName))
                    Next
                End If
                cmd.ExecuteNonQuery()
                cmd.Dispose()
            End If
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
                conn.Dispose()
            End If
        End Try

        Return Nothing
    End Function

    Protected Sub ExecuteStoredProcedure(ByVal params As Dictionary(Of String, String), ByVal storedProcedure As String)
        Dim conn As New MySqlConnection
        Try
            Dim connectionString As String = ConfigurationManager.ConnectionStrings("EntropicConnectionString").ConnectionString
            conn.ConnectionString = connectionString
            conn.Open()
            Dim cmd = New MySqlCommand With {
                .Connection = conn,
                .CommandType = CommandType.StoredProcedure,
                .CommandText = storedProcedure
            }

            For Each paramName In params.Keys
                cmd.Parameters.AddWithValue(paramName, params(paramName))
            Next

            cmd.Parameters.AddWithValue("?parRetVal", "0")
            cmd.Parameters("?parRetVal").Direction = ParameterDirection.Output
            cmd.ExecuteNonQuery()
            cmd.Parameters.Clear()
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
                conn.Dispose()
            End If
        End Try
    End Sub


    ' ======================================================================
    ' Helper: estrazione descrizione breve (usata nel databinding in markup)
    ' ======================================================================
    Public Function sotto_stringa(ByVal testo As Object) As String
        Dim s As String = ""
        If testo IsNot Nothing Then
            s = Convert.ToString(testo)
        End If

        If String.IsNullOrEmpty(s) Then Return ""

        ' Decode eventuali entità HTML, rimuove tag e normalizza spazi
        Try
            s = System.Web.HttpUtility.HtmlDecode(s)
        Catch
            ' ignore
        End Try

        s = Regex.Replace(s, "<[^>]*>", " ")
        s = Regex.Replace(s, "\s+", " ").Trim()

        Dim maxLen As Integer = 180
        If s.Length > maxLen Then
            s = s.Substring(0, maxLen).Trim()
            If s.Length > 0 Then s &= "..."
        End If

        ' Encode output per evitare HTML injection nel markup
        Return Server.HtmlEncode(s)
    End Function



    ' ============================================================
    ' SEO (Catalogo)
    ' ============================================================
    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        Try
            EnsureCatalogSeo()
        Catch
            ' no-op
        End Try
    End Sub

    Private Sub EnsureCatalogSeo()
        Dim canonical As String = Request.Url.GetLeftPart(UriPartial.Path)

        ' Canonical: per navigazione categoria (st/ct/tp) manteniamo i parametri base,
        ' mentre per ricerca (q) o dettaglio (pid) restiamo su path pulito.
        Dim _pid As Integer = 0
        Integer.TryParse(Request.QueryString("pid"), _pid)
        Dim _q As String = QS("q", 80)

        If _pid <= 0 AndAlso String.IsNullOrEmpty(_q) Then
            Dim _st As Integer = 0
            Dim _ct As Integer = 0
            Integer.TryParse(Request.QueryString("st"), _st)
            Integer.TryParse(Request.QueryString("ct"), _ct)
            Dim _tpRaw As String = Convert.ToString(Request.QueryString("tp"))

            Dim parts As New List(Of String)()
            If _st > 0 Then parts.Add("st=" & _st.ToString())
            If _ct > 0 Then parts.Add("ct=" & _ct.ToString())

            If Not String.IsNullOrEmpty(_tpRaw) Then
                Dim _tp As String = _tpRaw.Replace("|", ",")
                Dim firstTp As String = ""
                For Each token As String In _tp.Split(","c)
                    Dim id As Integer = 0
                    If Integer.TryParse(token.Trim(), id) AndAlso id > 0 Then
                        firstTp = id.ToString()
                        Exit For
                    End If
                Next
                If Not String.IsNullOrEmpty(firstTp) Then
                    parts.Add("tp=" & firstTp)
                End If
            End If

            If parts.Count > 0 Then
                canonical &= "?" & String.Join("&", parts.ToArray())
            End If
        End If

        If String.IsNullOrEmpty(Page.Title) Then
            Page.Title = "Catalogo prodotti"
        End If

        AddOrReplaceMeta(Me.Page, "robots", "index, follow")
        AddOrReplaceMeta(Me.Page, "description", "Catalogo prodotti - " & Page.Title)
        SetCanonical(Me.Page, canonical)

        Dim jsonLd As String = BuildSimplePageJsonLd(Page.Title, "Catalogo prodotti", canonical)
        SetJsonLdOnMaster(Me.Page, jsonLd)
    End Sub

    ' ============================================================
    ' SEO helpers locali (compatibilità: SeoBuilder non disponibile)
    ' ============================================================

    Private Shared Sub AddOrReplaceMeta(ByVal page As System.Web.UI.Page, ByVal metaName As String, ByVal metaContent As String)
        If page Is Nothing OrElse page.Header Is Nothing Then Exit Sub

        Dim found As System.Web.UI.HtmlControls.HtmlMeta = Nothing
        For Each ctrl As Control In page.Header.Controls
            Dim m As System.Web.UI.HtmlControls.HtmlMeta = TryCast(ctrl, System.Web.UI.HtmlControls.HtmlMeta)
            If m IsNot Nothing AndAlso String.Equals(m.Name, metaName, StringComparison.OrdinalIgnoreCase) Then
                found = m
                Exit For
            End If
        Next

        If found Is Nothing Then
            found = New System.Web.UI.HtmlControls.HtmlMeta()
            found.Name = metaName
            page.Header.Controls.Add(found)
        End If

        found.Content = metaContent
    End Sub

    Private Shared Sub SetCanonical(ByVal page As System.Web.UI.Page, ByVal canonicalUrl As String)
        If page Is Nothing OrElse page.Header Is Nothing Then Exit Sub
        If String.IsNullOrWhiteSpace(canonicalUrl) Then Exit Sub

        Dim found As System.Web.UI.HtmlControls.HtmlLink = Nothing
        For Each ctrl As Control In page.Header.Controls
            Dim l As System.Web.UI.HtmlControls.HtmlLink = TryCast(ctrl, System.Web.UI.HtmlControls.HtmlLink)
            If l IsNot Nothing Then
                Dim rel As String = Convert.ToString(l.Attributes("rel"))
                If String.Equals(rel, "canonical", StringComparison.OrdinalIgnoreCase) Then
                    found = l
                    Exit For
                End If
            End If
        Next

        If found Is Nothing Then
            found = New System.Web.UI.HtmlControls.HtmlLink()
            found.Attributes("rel") = "canonical"
            page.Header.Controls.Add(found)
        End If

        found.Href = canonicalUrl
    End Sub
    Private Shared Function BuildSimplePageJsonLd(ByVal pageTitle As String, ByVal descr As String, ByVal canonicalUrl As String) As String
        Dim sb As New StringBuilder()
        sb.Append("{""@context"":""https://schema.org"",""@type"":""WebPage""")
        sb.Append(",""name"":""").Append(JsonEscape(pageTitle)).Append("""")
        sb.Append(",""url"":""").Append(JsonEscape(canonicalUrl)).Append("""")
        If Not String.IsNullOrEmpty(descr) Then
            sb.Append(",""description"":""").Append(JsonEscape(descr)).Append("""")
        End If
        sb.Append("}")
        Return sb.ToString()
    End Function

    Private Shared Function JsonEscape(ByVal s As String) As String
        If s Is Nothing Then Return ""
        Dim sb As New StringBuilder(s.Length + 16)

        For Each ch As Char In s
            Select Case ch
                Case """"c
                    ' JSON: \"
                    sb.Append("\\")
                    sb.Append(ChrW(34))
                Case "\"c
                    ' JSON: \\
                    sb.Append("\\\\")
                Case ControlChars.Cr
                    sb.Append("\\r")
                Case ControlChars.Lf
                    sb.Append("\\n")
                Case ControlChars.Tab
                    sb.Append("\\t")
                Case Else
                    Dim code As Integer = AscW(ch)
                    If code < 32 Then
                        sb.Append("\\u").Append(code.ToString("x4"))
                    Else
                        sb.Append(ch)
                    End If
            End Select
        Next

        Return sb.ToString()
    End Function
    Private Shared Sub SetJsonLdOnMaster(ByVal page As System.Web.UI.Page, ByVal jsonLd As String)
        Try
            Dim m As Object = page.Master
            If m IsNot Nothing Then
                Dim prop = m.GetType().GetProperty("SeoJsonLd")
                If prop IsNot Nothing AndAlso prop.CanWrite Then
                    prop.SetValue(m, jsonLd, Nothing)
                    Return
                End If
            End If
        Catch
            ' NOP
        End Try

        Try
            Dim ph As Control = page.Header.FindControl("HeadContent")
            If ph Is Nothing Then
                ' fallback: inject directly in <head>
                ph = page.Header
            End If

            Dim lit As New Literal()
            lit.ID = "litJsonLd"
            lit.Text = "<script type=""application/ld+json"">" & jsonLd & "</script>"
            ph.Controls.Add(lit)
        Catch
            ' NOP
        End Try
    End Sub

    '--- Security helpers (XSS + QueryString validation) ------------------------
    Protected Function H(value As Object) As String
        Return Server.HtmlEncode(Convert.ToString(value))
    End Function

    Protected Function HA(value As Object) As String
        Return System.Web.HttpUtility.HtmlAttributeEncode(Convert.ToString(value))
    End Function

    Private Function BuildInParamsForSds(ByVal idsCsv As String,
                                        ByVal paramPrefix As String,
                                        ByVal pc As System.Web.UI.WebControls.ParameterCollection) As String
        If String.IsNullOrWhiteSpace(idsCsv) Then Return ""

        Dim parts() As String = idsCsv.Split(","c)
        Dim placeholders As New List(Of String)()
        Dim i As Integer = 0

        For Each p As String In parts
            Dim vRaw As String = p.Trim()
            If vRaw = "" Then Continue For

            Dim v As Integer
            If Not Integer.TryParse(vRaw, v) Then Continue For
            If v <= 0 Then Continue For

            Dim name As String = paramPrefix & i.ToString()

            ' Avoid accidental collisions if the same prefix gets reused.
            If pc(name) IsNot Nothing Then
                i += 1
                Continue For
            End If

            placeholders.Add("?" & name)
            pc.Add(New System.Web.UI.WebControls.Parameter(name, TypeCode.Int32, v.ToString()))
            i += 1
        Next

        If placeholders.Count = 0 Then Return ""
        Return String.Join(",", placeholders.ToArray())
    End Function

    ' Escape value for safe inclusion inside MySQL string literals within LIKE patterns.
    Protected Function SqlEscapeLike(value As String, Optional maxLen As Integer = 120) As String
        If value Is Nothing Then Return ""
        Dim v As String = value.Trim()
        If v.Length > maxLen Then v = v.Substring(0, maxLen)
        ' MySqlHelper.EscapeString escapes quotes and backslashes for use inside string literals.
        Return MySql.Data.MySqlClient.MySqlHelper.EscapeString(v)
    End Function

    Private Function QS(key As String, Optional maxLen As Integer = 200) As String
        Dim v As String = Convert.ToString(Request.QueryString(key))
        If v Is Nothing Then Return ""
        v = v.Trim()
        If v.Length > maxLen Then v = v.Substring(0, maxLen)
        Return v
    End Function

    Private Function QSSplit(key As String) As String()
        Dim v As String = QS(key)
        If String.IsNullOrEmpty(v) Then Return New String() {}
        Return v.Split("|"c)
    End Function

    Private Function IsValidMultiIdList(raw As String) As Boolean
        If String.IsNullOrEmpty(raw) Then Return False
        ' Format used in this project: index|id|id|id...
        Return System.Text.RegularExpressions.Regex.IsMatch(raw, "^\d+(\|\d+)+$")
    End Function

    Private Function IsValidIndexAndValue(raw As String) As Boolean
        If String.IsNullOrEmpty(raw) Then Return False
        ' Format: index|value  (value can be numeric or short token)
        If raw.Length > 80 Then Return False
        Return System.Text.RegularExpressions.Regex.IsMatch(raw, "^\d+\|[A-Za-z0-9\-\._% ]+$")
    End Function

    ' UI helper: percentuale sconto (es. "-25%") calcolata in modo robusto.
    Protected Function GetDiscountPercent(oldPriceObj As Object, newPriceObj As Object) As String
        Dim oldD As Decimal = KeepStoreSecurity.SqlCleanDecimal(oldPriceObj, 0D)
        Dim newD As Decimal = KeepStoreSecurity.SqlCleanDecimal(newPriceObj, 0D)

        If oldD <= 0D OrElse newD <= 0D OrElse newD >= oldD Then Return ""

        Dim pctDec As Decimal = ((oldD - newD) / oldD) * 100D
        Dim pct As Integer = CInt(Math.Round(pctDec, 0, MidpointRounding.AwayFromZero))
        If pct <= 0 Then Return ""

        Return "-" & pct.ToString() & "%"
    End Function
    Protected Function HasPromo(ByVal inOffertaObj As Object, ByVal promoObj As Object) As Boolean
        ' InOfferta può arrivare come Boolean, Integer o String
        Dim inOff As Boolean = False
        If inOffertaObj IsNot Nothing AndAlso Not IsDBNull(inOffertaObj) Then
            Try
                If TypeOf inOffertaObj Is Boolean Then
                    inOff = CBool(inOffertaObj)
                Else
                    inOff = (Convert.ToInt32(inOffertaObj) <> 0)
                End If
            Catch
                inOff = False
            End Try
        End If
        If Not inOff Then Return False

        If promoObj Is Nothing OrElse IsDBNull(promoObj) Then Return False
        Dim promoVal As Decimal = KeepStoreSecurity.SqlCleanDecimal(promoObj, 0D)
        Return (promoVal > 0D)
    End Function

    Protected Function GetPriceNewText(ByVal inOffertaObj As Object, ByVal promoObj As Object, ByVal standardObj As Object) As String
        Dim valToShow As Object = standardObj
        If HasPromo(inOffertaObj, promoObj) Then valToShow = promoObj
        Dim d As Decimal = KeepStoreSecurity.SqlCleanDecimal(valToShow, 0D)
        If d <= 0D Then Return ""
        Return d.ToString("C")
    End Function

    Protected Function GetPriceOldText(ByVal inOffertaObj As Object, ByVal promoObj As Object, ByVal standardObj As Object) As String
        If Not HasPromo(inOffertaObj, promoObj) Then Return ""
        Dim d As Decimal = KeepStoreSecurity.SqlCleanDecimal(standardObj, 0D)
        If d <= 0D Then Return ""
        Return d.ToString("C")
    End Function


    Private Shared Sub CopyParams(ByVal src As ParameterCollection, ByVal dst As ParameterCollection)
        dst.Clear()
        For Each p As Parameter In src
            Dim np As New Parameter(p.Name, p.Type)
            np.DefaultValue = p.DefaultValue
            np.Direction = p.Direction
            np.ConvertEmptyStringToNull = p.ConvertEmptyStringToNull
            dst.Add(np)
        Next
    End Sub


    ' =========================
    ' WhatsApp share helpers
    ' =========================

    ' Ritorna la base URL del sito.
    ' - priorità: Session("AziendaUrl") (accetta con o senza schema)
    ' - fallback: Request.Url (authority della request corrente)
    Private Function GetSiteBaseUrl() As String
        Dim s As String = ""
        Try
            s = Convert.ToString(Session("AziendaUrl"))
        Catch
            s = ""
        End Try

        s = If(s, "").Trim()

        If s <> "" Then
            If Not (s.StartsWith("http://", StringComparison.OrdinalIgnoreCase) OrElse
                    s.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) Then
                s = "https://" & s
            End If

            Return s.TrimEnd("/"c)
        End If

        Dim req As HttpRequest = HttpContext.Current.Request
        Return req.Url.GetLeftPart(UriPartial.Authority).TrimEnd("/"c)
    End Function

    ' Usata dal markup (data-binding) per costruire il link di condivisione WhatsApp.
    Protected Function GetWhatsAppShareUrl(descrizione As Object, id As Object, tcid As Object) As String
        Dim descr As String = Convert.ToString(descrizione)
        Dim idStr As String = Convert.ToString(id)
        Dim tcidStr As String = Convert.ToString(tcid)

        Dim baseUrl As String = GetSiteBaseUrl()
        Dim articoloPath As String = Me.ResolveUrl("~/articolo.aspx")
        Dim articoloUrl As String = baseUrl & articoloPath & "?id=" & idStr & "&TCid=" & tcidStr

        Dim txt As String = descr & " - " & articoloUrl
        Dim url As String = "https://wa.me/?text=" & HttpUtility.UrlEncode(txt)

        ' Sicuro per attributo HTML (href)
        Return HttpUtility.HtmlAttributeEncode(url)
    End Function

    ' Usata dal markup (data-binding) per la src dell'icona.
    Protected Function GetWhatsAppIconUrl() As String
        Dim url As String = Me.ResolveUrl("~/Public/Images/WhatsApp-Symbolo.png")
        Return HttpUtility.HtmlAttributeEncode(url)
    End Function


End Class
